#! /bin/bash
   
python startup.py

