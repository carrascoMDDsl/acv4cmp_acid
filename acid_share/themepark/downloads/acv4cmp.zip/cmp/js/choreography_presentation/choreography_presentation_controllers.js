'use strict';

/*
 * choreography_presentation_controllers.js
 *
 * A Javascript exercise.
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 * 03/13/2014
 */




angular.module('cmpinterviewjs').controller(
    'ObjectHolderCtrl',
    [ '$scope',
function ( $scope) {


    $scope.holder = { };
    $scope.holder.obj = null;




    var pInitWith = function( theObject) {
        $scope.holder.obj = theObject;
    };
    if( pInitWith) {} /* CQT */
    $scope.pInitWith = pInitWith;



}]);





