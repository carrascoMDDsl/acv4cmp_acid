'use strict';

/*
 * choreography/beginandoutcome_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */


var mModule = angular.module("beginAndOutcomeTypes", []);



mModule.factory("BeginAndOutcomeTypes", [
    "ActivitySimpleTypes",
function( ActivitySimpleTypes){






    /* ******************************************************************************
     TYPE  Choreography.Begin
     */

    /* Define prototype. Inherits from another prototype */
    var aBegin_Prototype = (function( theSuperConstructor) {

        if( theSuperConstructor) {} /* CQT mistake */


        /* Configurable constants */

        var BEGINNAME_DEFAULT   = "Begin";


        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "Begin";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            var aName = theName;
            if( !aName) {
                aName = BEGINNAME_DEFAULT;
            }

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_ActivitySimple._pInit.apply( this, [ aName]);
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;



        return aPrototype;

    })( ActivitySimpleTypes.ActivitySimple.constructor);





    /* Define constructor for instances with the prototype. */

    var Begin_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_ActivitySimple = ActivitySimpleTypes.ActivitySimple.prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._pInit( theName);
    };
    Begin_Constructor.prototype = aBegin_Prototype;















    /* ******************************************************************************
     TYPE  Choreography.Outcome
     */

    /* Define prototype. Inherits from another prototype */
    var anOutcome_Prototype = (function( theSuperConstructor) {

        if( theSuperConstructor) {} /* CQT mistake */


        /* Configurable constants */


        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "Outcome";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_ActivitySimple._pInit.apply( this, [ theName]);
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;



        return aPrototype;

    })( ActivitySimpleTypes.ActivitySimple.constructor);





    /* Define constructor for instances with the prototype. */

    var Outcome_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_ActivitySimple = ActivitySimpleTypes.ActivitySimple.prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._pInit( theName);
    };
    Outcome_Constructor.prototype = anOutcome_Prototype;










    /* ******************************************************************************
     TYPE  Choreography.OutcomeSuccess
     */

    /* Define prototype. Inherits from another prototype */
    var anOutcomeSuccess_Prototype = (function( theSuperConstructor) {

        if( theSuperConstructor) {} /* CQT mistake */



        /* Configurable constants */
        var SUCCESSNAME_DEFAULT = "Success";



        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "OutcomeSuccess";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            var aName = theName;
            if( !aName) {
                aName = SUCCESSNAME_DEFAULT;
            }
            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Outcome._pInit.apply( this, [ aName]);
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;



        return aPrototype;

    })( Outcome_Constructor);





    /* Define constructor for instances with the prototype. */

    var OutcomeSuccess_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Outcome = anOutcome_Prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._pInit( theName);
    };
    OutcomeSuccess_Constructor.prototype = anOutcomeSuccess_Prototype;













    /* ******************************************************************************
     TYPE  Choreography.OutcomeFailure
     */

    /* Define prototype. Inherits from another prototype */
    var anOutcomeFailure_Prototype = (function( theSuperConstructor) {

        if( theSuperConstructor) {} /* CQT mistake */


        /* Configurable constants */
        var FAILURENAME_DEFAULT = "Failure";



        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "OutcomeFailure";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            var aName = theName;
            if( !aName) {
                aName = FAILURENAME_DEFAULT;
            }

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Outcome._pInit.apply( this, [ aName]);
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;



        return aPrototype;

    })( Outcome_Constructor);





    /* Define constructor for instances with the prototype. */

    var OutcomeFailure_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Outcome = anOutcome_Prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._pInit( theName);
    };
    OutcomeFailure_Constructor.prototype = anOutcomeFailure_Prototype;








    /* Expose component members */
    var someTypes = {
        "Module":        "BeginTypes",
        "Begin": {
            prototype:   aBegin_Prototype,
            constructor: Begin_Constructor
        },
        "Outcome": {
            prototype:   anOutcome_Prototype,
            constructor: Outcome_Constructor
        },
        "Success": {
            prototype:   anOutcomeSuccess_Prototype,
            constructor: OutcomeSuccess_Constructor
        },
        "Failure": {
            prototype:   anOutcomeFailure_Prototype,
            constructor: OutcomeFailure_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);











