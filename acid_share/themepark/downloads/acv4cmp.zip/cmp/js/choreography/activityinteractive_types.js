'use strict';

/*
 * choreography/activityinteractive_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */


var mModule = angular.module("activityInteractiveTypes", []);



mModule.factory("ActivityInteractiveTypes", [
    "ActivityTypes",
function( ActivityTypes){






    /* ******************************************************************************
     TYPE  Choreography.ActivityInteractive
     */

    /* Define prototype. Inherits from another prototype */
    var aActivityInteractive_Prototype = (function( theSuperConstructor) {

        if( theSuperConstructor) {} /* CQT mistake */


        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "ActivityInteractive";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */

        aPrototype._v_BehaviorsSend    = null;
        aPrototype._v_BehaviorsReceive = null;
        aPrototype._v_BehaviorsError   = null;




        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Activity._pInit.apply( this, [ theName]);

            this._v_BehaviorsSend    = [ ];
            this._v_BehaviorsReceive = [ ];
            this._v_BehaviorsError   = [ ];
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;









        /* ******************************************************************
         BehaviorsSend contents.
         */


        var behaviorsSend = function() {

            return this._v_BehaviorsSend.slice();
        };
        if( behaviorsSend) {} /* CQT */
        aPrototype.behaviorsSend = behaviorsSend;





        var hasBehaviorSend = function( theBehaviorSend) {
            if( !theBehaviorSend) {
                return false;
            }

            if( this._v_BehaviorsSend.indexOf( theBehaviorSend) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasBehaviorSend) {} /* CQT */
        aPrototype.hasBehaviorSend = hasBehaviorSend;







        var behaviorsSendAdd = function( theBehaviorSend) {
            if( !theBehaviorSend) {
                return;
            }

            if( this.hasBehaviorSend( theBehaviorSend)) {
                return;
            }

            this._v_BehaviorsSend.push( theBehaviorSend);
        };
        if( behaviorsSendAdd) {} /* CQT */
        aPrototype.behaviorsSendAdd = behaviorsSendAdd;







        var behaviorsSendRemove = function( theBehaviorSend) {
            if( !theBehaviorSend) {
                return;
            }

            var anBehaviorSendIndex = this._v_BehaviorsSend.indexOf( theBehaviorSend);
            if( anBehaviorSendIndex < 0) {
                return;
            }

            this._v_BehaviorsSend.splice( anBehaviorSendIndex, 1);
        };
        if( behaviorsSendRemove) {} /* CQT */
        aPrototype.behaviorsSendRemove = behaviorsSendRemove;









        /* ******************************************************************
         BehaviorsReceive contents.
         */


        var behaviorsReceive = function() {

            return this._v_BehaviorsReceive.slice();
        };
        if( behaviorsReceive) {} /* CQT */
        aPrototype.behaviorsReceive = behaviorsReceive;





        var hasBehaviorReceive = function( theBehaviorReceive) {
            if( !theBehaviorReceive) {
                return false;
            }

            if( this._v_BehaviorsReceive.indexOf( theBehaviorReceive) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasBehaviorReceive) {} /* CQT */
        aPrototype.hasBehaviorReceive = hasBehaviorReceive;







        var behaviorsReceiveAdd = function( theBehaviorReceive) {
            if( !theBehaviorReceive) {
                return;
            }

            if( this.hasBehaviorReceive( theBehaviorReceive)) {
                return;
            }

            this._v_BehaviorsReceive.push( theBehaviorReceive);
        };
        if( behaviorsReceiveAdd) {} /* CQT */
        aPrototype.behaviorsReceiveAdd = behaviorsReceiveAdd;







        var behaviorsReceiveRemove = function( theBehaviorReceive) {
            if( !theBehaviorReceive) {
                return;
            }

            var anBehaviorReceiveIndex = this._v_BehaviorsReceive.indexOf( theBehaviorReceive);
            if( anBehaviorReceiveIndex < 0) {
                return;
            }

            this._v_BehaviorsReceive.splice( anBehaviorReceiveIndex, 1);
        };
        if( behaviorsReceiveRemove) {} /* CQT */
        aPrototype.behaviorsReceiveRemove = behaviorsReceiveRemove;










        /* ******************************************************************
         BehaviorsError contents.
         */


        var behaviorsError = function() {

            return this._v_BehaviorsError.slice();
        };
        if( behaviorsError) {} /* CQT */
        aPrototype.behaviorsError = behaviorsError;





        var hasBehaviorError = function( theBehaviorError) {
            if( !theBehaviorError) {
                return false;
            }

            if( this._v_BehaviorsError.indexOf( theBehaviorError) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasBehaviorError) {} /* CQT */
        aPrototype.hasBehaviorError = hasBehaviorError;







        var behaviorsErrorAdd = function( theBehaviorError) {
            if( !theBehaviorError) {
                return;
            }

            if( this.hasBehaviorError( theBehaviorError)) {
                return;
            }

            this._v_BehaviorsError.push( theBehaviorError);
        };
        if( behaviorsErrorAdd) {} /* CQT */
        aPrototype.behaviorsErrorAdd = behaviorsErrorAdd;







        var behaviorsErrorRemove = function( theBehaviorError) {
            if( !theBehaviorError) {
                return;
            }

            var anBehaviorErrorIndex = this._v_BehaviorsError.indexOf( theBehaviorError);
            if( anBehaviorErrorIndex < 0) {
                return;
            }

            this._v_BehaviorsError.splice( anBehaviorErrorIndex, 1);
        };
        if( behaviorsErrorRemove) {} /* CQT */
        aPrototype.behaviorsErrorRemove = behaviorsErrorRemove;





        return aPrototype;

    })( ActivityTypes.Activity.constructor);







    /* Define constructor for instances with the prototype. */

    var ActivityInteractive_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Activity = ActivityTypes.Activity.prototype;

        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_BehaviorsSend    = null;
        this._v_BehaviorsReceive = null;
        this._v_BehaviorsError   = null;

        this._pInit( theName);
    };
    ActivityInteractive_Constructor.prototype = aActivityInteractive_Prototype;














    /* ******************************************************************************
     TYPE  Choreography.ActivityRequestReply
     */

    /* Define prototype. Inherits from another prototype */
    var aActivityRequestReply_Prototype = (function( theSuperConstructor) {

        if( theSuperConstructor) {} /* CQT mistake */


        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "ActivityRequestReply";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_ActivityInteractive._pInit.apply( this, [ theName]);

        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;




        return aPrototype;

    })( ActivityInteractive_Constructor);





    /* Define constructor for instances with the prototype. */

    var ActivityRequestReply_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_ActivityInteractive = aActivityInteractive_Prototype;

        /* Init object layout with member properties ASAP for the benefit of JIT */

        this._pInit( theName);
    };
    ActivityRequestReply_Constructor.prototype = aActivityRequestReply_Prototype;

















    /* ******************************************************************************
     TYPE  Choreography.ActivityReceiveRespond
     */

    /* Define prototype. Inherits from another prototype */
    var aActivityReceiveRespond_Prototype = (function( theSuperConstructor) {

         if( theSuperConstructor) {} /* CQT mistake */

        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "ActivityReceiveRespond";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_ActivityInteractive._pInit.apply( this, [ theName]);

        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;






        return aPrototype;

    })( ActivityInteractive_Constructor);





    /* Define constructor for instances with the prototype. */

    var ActivityReceiveRespond_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_ActivityInteractive = aActivityInteractive_Prototype;

        /* Init object layout with member properties ASAP for the benefit of JIT */

        this._pInit( theName);
    };
    ActivityReceiveRespond_Constructor.prototype = aActivityReceiveRespond_Prototype;











    /* Expose component members */
    var someTypes = {
        "Module":        "ActivityRequestReplyTypes",
        "ActivityRequestReply": {
            prototype:   aActivityRequestReply_Prototype,
            constructor: ActivityRequestReply_Constructor
        },
        "ActivityReceiveRespond": {
            prototype:   aActivityReceiveRespond_Prototype,
            constructor: ActivityReceiveRespond_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);











