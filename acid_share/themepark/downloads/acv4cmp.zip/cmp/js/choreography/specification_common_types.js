'use strict';

/*
 * choreography/specification_common_objects.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */



var mModule = angular.module("choreographySpecificationCommonTypes", []);



mModule.factory("ChoreographySpecificationCommonTypes", [
    "ChoreographyCommonTypes",
    function( ChoreographyCommonTypes){





    /* ******************************************************************************
     TYPE  Choreography.Specification
     */

    /* Define prototype. Inherits from another prototype */
    var aSpecification_Prototype = (function( theSuperConstructor) {
        if( theSuperConstructor) {} /* CQT */
        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package= "Choreography";
        aPrototype._v_Type   = "Specification";
        aPrototype._v_Kind   = "Type";
        aPrototype._v_Layer  = "Object";



        /* Prototype member properties */





        /* Supply essential contextual parameters */
        var _pInit = function() {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Common._pInit.apply( this);

        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;





        return aPrototype;

    })( ChoreographyCommonTypes.Common.constructor);







    /* Define constructor for instances with the prototype. */

    var Specification_Constructor = function() {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Common = ChoreographyCommonTypes.Common.prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */

        this._pInit();
    };
    Specification_Constructor.prototype = aSpecification_Prototype;










    /* ******************************************************************************
     TYPE  Choreography.NamedSpecification
     */


    /* Define prototype. Inherits from another prototype */
    var aNamedSpecification_Prototype = (function( theSuperConstructor) {
        if( theSuperConstructor) {} /* CQT */

        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package= "Choreography";
        aPrototype._v_Type   = "NamedSpecification";
        aPrototype._v_Kind   = "Type";
        aPrototype._v_Layer  = "Object";



        /* Prototype member properties */

        aPrototype._v_Name = null;




        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Specification._pInit.apply( this);

            this._v_Name = theName;
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;





        var instanceName = function() {
            return this._v_Name;
        };
        if( instanceName) {} /* CQT */
        aPrototype.instanceName = instanceName;




        return aPrototype;

    })( Specification_Constructor);







    /* Define constructor for instances with the prototype. */

    var NamedSpecification_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Specification = aSpecification_Prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_Name = null;

        this._pInit( theName);
    };
    NamedSpecification_Constructor.prototype = aNamedSpecification_Prototype;












    /* Expose component members */
    var someTypes = {
        "Module":        "ChoreographySpecificationCommonTypes",
        "Specification": {
            prototype:   aSpecification_Prototype,
            constructor: Specification_Constructor
        },
        "NamedSpecification": {
            prototype:   aNamedSpecification_Prototype,
            constructor: NamedSpecification_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);









