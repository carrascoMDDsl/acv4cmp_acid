'use strict';

/*
 * choreography/chained_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */


var mModule = angular.module("chainedTypes", []);



mModule.factory("ChainedTypes", [
    "ChoreographySpecificationCommonTypes",
function(
    ChoreographySpecificationCommonTypes
    ){








    /* ******************************************************************************
     TYPE  Choreography.Chained
     */

    /* Define prototype. Inherits from another prototype */
    var aChained_Prototype = (function( theSuperConstructor) {


        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "Chained";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */


        aPrototype._v_SuccessorChains = null;
        aPrototype._v_PredecessorChains = null;



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_NamedSpecification._pInit.apply( this, [ theName]);

            this._v_SuccessorChains = [ ];
            this._v_PredecessorChains = [ ];
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;





        var chainedName = function() {

            /* Delegate on super prototype */
            return this._v_SuperPrototype_NamedSpecification.instanceName.apply( this);
        };
        if( chainedName) {} /* CQT */
        aPrototype.chainedName = chainedName;




        
        
        


        /* ******************************************************************
         Successor Chains references.
         */



        var successorChains = function() {

            return this._v_SuccessorChains.slice();
        };
        if( successorChains) {} /* CQT */
        aPrototype.successorChains = successorChains;





        var hasSuccessorChain = function( theChain) {
            if( !theChain) {
                return false;
            }

            if( this._v_SuccessorChains.indexOf( theChain) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasSuccessorChain) {} /* CQT */
        aPrototype.hasSuccessorChain = hasSuccessorChain;






        var successorChainsTo = function( theChained) {
            var someChains = [];

            if( !theChained) {
                return someChains;
            }

            var aNumChains = this._v_SuccessorChains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_SuccessorChains[ aChainIndex];
                if( aChain.successors().indexOf( theChained) >= 0) {
                    someChains.push( aChain);
                }
            }

            return someChains;
        };
        if( successorChainsTo) {} /* CQT */
        aPrototype.successorChainsTo = successorChainsTo;







        var successorChainsToNamed = function( theChainedName) {
            var someChains = [];

            if( !theChainedName) {
                return someChains;
            }

            var aNumChains = this._v_SuccessorChains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {

                var aChain = this._v_SuccessorChains[ aChainIndex];
                var someSuccessors = aChain.successors();

                var aNumSuccessors = someSuccessors.length;
                for( var aSuccessorIndex = 0; aSuccessorIndex < aNumSuccessors; aChainIndex++) {

                    var aSuccessor = someSuccessors[ aSuccessorIndex];
                    if( aSuccessor.chainedName() == theChainedName) {
                        someChains.push( aChain);
                    }
                }
            }

            return someChains;
        };
        if( successorChainsToNamed) {} /* CQT */
        aPrototype.successorChainsToNamed = successorChainsToNamed;





        var hasSuccessorChainTo = function( theChained) {
            if( !theChained) {
                return false;
            }

            var aNumChains = this._v_SuccessorChains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_SuccessorChains[ aChainIndex];
                if( aChain.successors.indexOf( theChained) >= 0) {
                    return true;
                }
            }

            return true;
        };
        if( hasSuccessorChainTo) {} /* CQT */
        aPrototype.hasSuccessorChainTo = hasSuccessorChainTo;





        var hasSuccessorChainToNamed = function( theChainedName) {
            if( !theChainedName) {
                return false;
            }

            var aChain = this._v_SuccessorChains[ aChainIndex];
            var someSuccessors = aChain.successors();

            var aNumSuccessors = someSuccessors.length;
            for( var aSuccessorIndex = 0; aSuccessorIndex < aNumSuccessors; aChainIndex++) {

                var aSuccessor = someSuccessors[ aSuccessorIndex];
                if( aSuccessor.chainedName() == theChainedName) {
                    return true;
                }
            }
            return false;
        };
        if( hasSuccessorChainToNamed) {} /* CQT */
        aPrototype.hasSuccessorChainToNamed = hasSuccessorChainToNamed;






        var successorChainAdd_privileged = function( theChain) {
            if( !theChain) {
                return;
            }

            if( this.hasSuccessorChain( theChain)) {
                return;
            }

            this._v_SuccessorChains.push( theChain);
        };
        if( successorChainAdd_privileged) {} /* CQT */
        aPrototype.successorChainAdd_privileged = successorChainAdd_privileged;







        var successorChainRemove_privileged = function( theChain) {
            if( !theChain) {
                return;
            }

            var aChainIndex = this._v_SuccessorChains.indexOf( theChain);
            if( aChainIndex < 0) {
                return;
            }

            this._v_SuccessorChains.splice( aChainIndex, 1);
        };
        if( successorChainRemove_privileged) {} /* CQT */
        aPrototype.successorChainRemove_privileged = successorChainRemove_privileged;











        /* ******************************************************************
         Predecessor Chains references.
         */



        var predecessorChains = function() {

            return this._v_PredecessorChains.slice();
        };
        if( predecessorChains) {} /* CQT */
        aPrototype.predecessorChains = predecessorChains;





        var hasPredecessorChain = function( theChain) {
            if( !theChain) {
                return false;
            }

            if( this._v_PredecessorChains.indexOf( theChain) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasPredecessorChain) {} /* CQT */
        aPrototype.hasPredecessorChain = hasPredecessorChain;






        var predecessorChainsTo = function( theChained) {
            var someChains = [];

            if( !theChained) {
                return someChains;
            }

            var aNumChains = this._v_PredecessorChains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_PredecessorChains[ aChainIndex];
                if( aChain.predecessors().indexOf( theChained) >= 0) {
                    someChains.push( aChain);
                }
            }

            return someChains;
        };
        if( predecessorChainsTo) {} /* CQT */
        aPrototype.predecessorChainsTo = predecessorChainsTo;







        var predecessorChainsToNamed = function( theChainedName) {
            var someChains = [];

            if( !theChainedName) {
                return someChains;
            }

            var aNumChains = this._v_PredecessorChains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {

                var aChain = this._v_PredecessorChains[ aChainIndex];
                var somePredecessors = aChain.predecessors();

                var aNumPredecessors = somePredecessors.length;
                for( var aPredecessorIndex = 0; aPredecessorIndex < aNumPredecessors; aChainIndex++) {

                    var aPredecessor = somePredecessors[ aPredecessorIndex];
                    if( aPredecessor.chainedName() == theChainedName) {
                        someChains.push( aChain);
                    }
                }
            }

            return someChains;
        };
        if( predecessorChainsToNamed) {} /* CQT */
        aPrototype.predecessorChainsToNamed = predecessorChainsToNamed;





        var hasPredecessorChainTo = function( theChained) {
            if( !theChained) {
                return false;
            }

            var aNumChains = this._v_PredecessorChains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_PredecessorChains[ aChainIndex];
                if( aChain.predecessors.indexOf( theChained) >= 0) {
                    return true;
                }
            }

            return true;
        };
        if( hasPredecessorChainTo) {} /* CQT */
        aPrototype.hasPredecessorChainTo = hasPredecessorChainTo;





        var hasPredecessorChainToNamed = function( theChainedName) {
            if( !theChainedName) {
                return false;
            }

            var aChain = this._v_PredecessorChains[ aChainIndex];
            var somePredecessors = aChain.predecessors();

            var aNumPredecessors = somePredecessors.length;
            for( var aPredecessorIndex = 0; aPredecessorIndex < aNumPredecessors; aChainIndex++) {

                var aPredecessor = somePredecessors[ aPredecessorIndex];
                if( aPredecessor.chainedName() == theChainedName) {
                    return true;
                }
            }
            return false;
        };
        if( hasPredecessorChainToNamed) {} /* CQT */
        aPrototype.hasPredecessorChainToNamed = hasPredecessorChainToNamed;






        var predecessorChainAdd_privileged = function( theChain) {
            if( !theChain) {
                return;
            }

            if( this.hasPredecessorChain( theChain)) {
                return;
            }

            this._v_PredecessorChains.push( theChain);
        };
        if( predecessorChainAdd_privileged) {} /* CQT */
        aPrototype.predecessorChainAdd_privileged = predecessorChainAdd_privileged;







        var predecessorChainRemove_privileged = function( theChain) {
            if( !theChain) {
                return;
            }

            var aChainIndex = this._v_PredecessorChains.indexOf( theChain);
            if( aChainIndex < 0) {
                return;
            }

            this._v_PredecessorChains.splice( aChainIndex, 1);
        };
        if( predecessorChainRemove_privileged) {} /* CQT */
        aPrototype.predecessorChainRemove_privileged = predecessorChainRemove_privileged;










        return aPrototype;

    })( ChoreographySpecificationCommonTypes.NamedSpecification.constructor);









    /* Define constructor for instances with the prototype. */

    var Chained_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_NamedSpecification = ChoreographySpecificationCommonTypes.NamedSpecification.prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_SuccessorChains = null;
        this._v_PredecessorChains = null;

        this._pInit( theName);
    };
    Chained_Constructor.prototype = aChained_Prototype;




















    /* ******************************************************************************
     TYPE  Choreography.Chain
     */

    /* Define prototype. Inherits from another prototype */
    var aChain_Prototype = (function(
        theSuperConstructor) {



        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "Chain";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */

        aPrototype._v_Activity              = null;
        aPrototype._v_Guard                 = null;
        aPrototype._v_Predecessors = null;
        aPrototype._v_Successors   = null;




        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_NamedSpecification._pInit.apply( this, [ theName]);

            this._v_Activity              = null;
            this._v_Guard                 = null;
            this._v_Predecessors = null;
            this._v_Successors   = null;
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;





        var guard = function() {
            return this._v_Guard;
        };
        if( guard) {} /* CQT */
        aPrototype.guard = guard;





        var guardSet = function( theGuard) {
            if( !theGuard) {
                return;
            }
            this._v_Guard = theGuard;
        };
        if( guardSet) {} /* CQT */
        aPrototype.guardSet = guardSet;





        var guardUnset = function() {

            this._v_Guard = null;
        };
        if( guardUnset) {} /* CQT */
        aPrototype.guardUnset = guardUnset;






        /* ******************************************************************
         Composite Activity aggregation container.
         */

        var activity = function() {

            return this._v_Activity;
        };
        if( activity) {} /* CQT */
        aPrototype.activity = activity;




        var _activitySet_privileged = function( theChained) {

            if( !theChained) {
                return;
            }

            this._v_Activity   = theChained;
        };
        if( _activitySet_privileged) {} /* CQT */
        aPrototype._activitySet_privileged = _activitySet_privileged;





        var _activityUnset_privileged = function() {

            this._v_Activity   = null;
        };
        if( _activityUnset_privileged) {} /* CQT */
        aPrototype._activityUnset_privileged = _activityUnset_privileged;





        /* ******************************************************************
         Predecessors references.
         */


        var predecessors = function() {

            return this._v_Predecessors.slice();
        };
        if( predecessors) {} /* CQT */
        aPrototype.predecessors = predecessors;





        var hasPredecessor = function( theChained) {
            if( !theChained) {
                return false;
            }

            if( this._v_Predecessors.indexOf( theChained) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasPredecessor) {} /* CQT */
        aPrototype.hasPredecessor = hasPredecessor;






        var predecessorByName = function( theChainedName) {
            if( !theChainedName) {
                return null;
            }

            var aNumPredecessors = this._v_Predecessors.length;
            if( !aNumPredecessors) {
                return null;
            }

            for( var aPredecessorIndex = 0; aPredecessorIndex < aNumPredecessors; aPredecessorIndex++) {
                var aPredecessor = this._v_Predecessors[ aPredecessorIndex];
                if( aPredecessor.chainedName() == theChainedName) {
                    return aPredecessor;
                }
            }

            return null;
        };
        if( predecessorByName) {} /* CQT */
        aPrototype.predecessorByName = predecessorByName;





        var hasPredecessorNamed = function( theChainedName) {
            if( !theChainedName) {
                return false;
            }

            var aPredecessor = this.predecessorByName( theChainedName);
            if( !aPredecessor) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasPredecessorNamed) {} /* CQT */
        aPrototype.hasPredecessorNamed = hasPredecessorNamed;






        var predecessorsAdd_privileged = function( theChained) {
            if( !theChained) {
                return;
            }

            if( this.hasPredecessor( theChained)) {
                return;
            }

            this._v_Predecessors.push( theChained);
        };
        if( predecessorsAdd_privileged) {} /* CQT */
        aPrototype.predecessorsAdd_privileged = predecessorsAdd_privileged;





        var predecessorsRemove_privileged = function( theChained) {
            if( !theChained) {
                return;
            }

            var aPredecessorIndex = this._v_Predecessors.indexOf( theChained);
            if( aPredecessorIndex < 0) {
                return;
            }

            this._v_Predecessors.splice( aPredecessorIndex, 1);
        };
        if( predecessorsRemove_privileged) {} /* CQT */
        aPrototype.predecessorsRemove_privileged = predecessorsRemove_privileged;







        /* ******************************************************************
         Successors references.
        */


        var successors = function() {

            return this._v_Successors.slice();
        };
        if( successors) {} /* CQT */
        aPrototype.successors = successors;




        var hasSuccessor = function( theChained) {
            if( !theChained) {
                return false;
            }

            if( this._v_Successors.indexOf( theChained) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasSuccessor) {} /* CQT */
        aPrototype.hasSuccessor = hasSuccessor;






        var successorByName = function( theChainedName) {
            if( !theChainedName) {
                return null;
            }

            var aNumSuccesors = this._v_Successors.length;
            if( !aNumSuccesors) {
                return null;
            }

            for( var aSuccesorIndex = 0; aSuccesorIndex < aNumSuccesors; aSuccesorIndex++) {
                var aSuccesor = this._v_Successors[ aSuccesorIndex];
                if( aSuccesor.chainedName() == theChainedName) {
                    return aSuccesor;
                }
            }

            return null;
        };
        if( successorByName) {} /* CQT */
        aPrototype.successorByName = successorByName;





        var hasSuccessorNamed = function( theChainedName) {
            if( !theChainedName) {
                return false;
            }

            var aSuccessor = this.successorByName( theChainedName);
            if( !aSuccessor) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasSuccessorNamed) {} /* CQT */
        aPrototype.hasSuccessorNamed = hasSuccessorNamed;






        var successorsAdd_privileged = function( theChained) {
            if( !theChained) {
                return;
            }

            if( this.hasSuccessor( theChained)) {
                return;
            }

            this._v_Successors.push( theChained);
        };
        if( successorsAdd_privileged) {} /* CQT */
        aPrototype.successorsAdd_privileged = successorsAdd_privileged;





        var successorsRemove_privileged = function( theChained) {
            if( !theChained) {
                return;
            }

            var aSuccessorIndex = this._v_Successors.indexOf( theChained);
            if( aSuccessorIndex < 0) {
                return;
            }

            this._v_Successors.splice( aSuccessorIndex, 1);
        };
        if( successorsRemove_privileged) {} /* CQT */
        aPrototype.successorsRemove_privileged = successorsRemove_privileged;





        return aPrototype;

    })( ChoreographySpecificationCommonTypes.Specification.constructor);









    /* Define constructor for instances with the prototype. */

    var Chain_Constructor = function( theName, theGuard) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_NamedSpecification = ChoreographySpecificationCommonTypes.Specification.prototype;

        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_Activity              = null;
        this._v_Guard                 = null;
        this._v_Predecessors = null;
        this._v_Successors   = null;

        this._pInit( theName, theGuard);
    };
    Chain_Constructor.prototype = aChain_Prototype;






    /* Expose component members */
    var someTypes = {
        "Module":        "ChainedTypes",
        "Chained": {
            prototype:   aChained_Prototype,
            constructor: Chained_Constructor
        },
        "Chain": {
            prototype:   aChain_Prototype,
            constructor: Chain_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);











