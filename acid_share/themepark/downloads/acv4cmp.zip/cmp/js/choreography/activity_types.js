'use strict';

/*
 * choreography/activity_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */


var mModule = angular.module("activityTypes", []);



mModule.factory("ActivityTypes", [
    "ChainedTypes",
    "DataStoreTypes",
    "EnablerTypes",
function(
    ChainedTypes,
    DataStoreTypes,
    EnablerTypes
    ){






    /* ******************************************************************************
     TYPE  Choreography.Activity
     */

    /* Define prototype. Inherits from another prototype */
    var aActivity_Prototype = (function(
        theSuperConstructor,
        theDataStoreConstructor,
        theEnablerImmediateConstructor,
        theEnablerProxyConstructor,
        theEnablerDependencyConstructor
        ) {



        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "Activity";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */


        aPrototype._v_Choreography   = null;
        aPrototype._v_ParentActivity = null;
        aPrototype._v_Enablers       = null;
        aPrototype._v_DataStores     = null;



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Chained._pInit.apply( this, [ theName]);


            this._v_Choreography   = null;
            this._v_ParentActivity = null;
            this._v_Enablers       = [ ];
            this._v_DataStores     = [ ];
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;





        var activityName = function() {

            /* Delegate on super prototype */
            return this._v_SuperPrototype_NamedSpecification.instanceName.apply( this);
        };
        if( activityName) {} /* CQT */
        aPrototype.activityName = activityName;






        /* ******************************************************************
         Choreography aggregation container.
        */

        var choreography = function() {

            if( this._v_Choreography) {
                return this._v_Choreography;
            }

            if( this._v_ParentActivity) {
                return this._v_ParentActivity.choreography();
            }

            return null;
        };
        if( choreography) {} /* CQT */
        aPrototype.choreography = choreography;






        var _choreographySet_privileged = function( theChoreography) {

            if( !theChoreography) {
                return;
            }

            this._v_Choreography   = theChoreography;
        };
        if( _choreographySet_privileged) {} /* CQT */
        aPrototype._choreographySet_privileged = _choreographySet_privileged;






        var _choreographyUnset_privileged = function() {

            this._v_Choreography   = null;
        };
        if( _choreographyUnset_privileged) {} /* CQT */
        aPrototype._choreographyUnset_privileged = _choreographyUnset_privileged;





        /* ******************************************************************
         Parent Activity aggregation container.
        */

        var parentActivity = function() {

            return this._v_ParentActivity;
        };
        if( parentActivity) {} /* CQT */
        aPrototype.parentActivity = parentActivity;




        var _parentActivitySet_privileged = function( theParentActivity) {

            if( !theParentActivity) {
                return;
            }

            this._v_ParentActivity   = theParentActivity;
        };
        if( _parentActivitySet_privileged) {} /* CQT */
        aPrototype._parentActivitySet_privileged = _parentActivitySet_privileged;





        var _parentActivityUnset_privileged = function() {

            this._v_ParentActivity   = null;
        };
        if( _parentActivityUnset_privileged) {} /* CQT */
        aPrototype._parentActivityUnset_privileged = _parentActivityUnset_privileged;









        /* ******************************************************************
         DataStores aggregation contents.
         */


        var dataStores = function() {

            return this._v_DataStores.slice();
        };
        if( dataStores) {} /* CQT */
        aPrototype.dataStores = dataStores;




        var hasDataStore = function( theDataStore) {
            if( !theDataStore) {
                return false;
            }

            if( this._v_DataStores.indexOf( theDataStore) < 0) {
                var a = null; if( a){} /* CQT */
                return false;
            }

            return true;
        };
        if( hasDataStore) {} /* CQT */
        aPrototype.hasDataStore = hasDataStore;




        var dataStoreByName = function( theDataStoreName) {
            if( !theDataStoreName) {
                return null;
            }

            var aNumDataStores = this._v_DataStores.length;
            if( !aNumDataStores) {
                return null;
            }

            for( var aDataStoreIndex = 0; aDataStoreIndex < aNumDataStores; aDataStoreIndex++) {
                var aDataStore = this._v_DataStores[ aDataStoreIndex];
                if( aDataStore.dataStoreName() == theDataStoreName) {
                    return aDataStore;
                }
            }

            return null;
        };
        if( dataStoreByName) {} /* CQT */
        aPrototype.dataStoreByName = dataStoreByName;





        var dataStoreCreate = function( theDataStoreName) {

            return this._dataStoreCreate( theDataStoreName, theDataStoreConstructor);
        };
        if( dataStoreCreate) {} /* CQT */
        aPrototype.dataStoreCreate = dataStoreCreate;





        var _dataStoreCreate = function( theDataStoreName, theDataStoreConstructor) {
            if( !theDataStoreName || !theDataStoreConstructor) {
                return null;
            }

            if( this.dataStoreByName( theDataStoreName)) {
                return null;
            }

            var aDataStore = new theDataStoreConstructor( theDataStoreName);

            var someSavedDataStores    = this._v_DataStores.slice();

            try {
                aDataStore._activitySet_privileged( this);
                this._v_DataStores.push( aDataStore);
            }
            catch( anException) {
                this._v_DataStores = someSavedDataStores;
            }

            return aDataStore;
        };
        if( _dataStoreCreate) {} /* CQT */
        aPrototype._dataStoreCreate = _dataStoreCreate;






        var dataStoreRemove = function( theDataStore) {
            if( !theDataStore) {
                return;
            }

            var anDataStoreIndex = this._v_DataStores.indexOf( theDataStore);
            if( anDataStoreIndex < 0) {
                return;
            }


            var someSavedDataStores    = this._v_DataStores.slice();

            try {
                theDataStore._activityUnset_privileged();
                this._v_DataStores.splice( anDataStoreIndex, 1);
            }
            catch( anException) {
                this._v_DataStores = someSavedDataStores;
            }
        };
        if( dataStoreRemove) {} /* CQT */
        aPrototype.dataStoreRemove = dataStoreRemove;









        /* ******************************************************************
         Enablers aggregation contents.
        */


        var enablers = function() {

            return this._v_Enablers.slice();
        };
        if( enablers) {} /* CQT */
        aPrototype.enablers = enablers;




        var hasEnabler = function( theEnabler) {
            if( !theEnabler) {
                return false;
            }

            if( this._v_Enablers.indexOf( theEnabler) < 0) {
                var a = null; if( a){} /* CQT */
                return false;
            }

            return true;
        };
        if( hasEnabler) {} /* CQT */
        aPrototype.hasEnabler = hasEnabler;




        var enablerByName = function( theEnablerName) {
            if( !theEnablerName) {
                return null;
            }

            var aNumEnablers = this._v_Enablers.length;
            if( !aNumEnablers) {
                return null;
            }

            for( var aEnablerIndex = 0; aEnablerIndex < aNumEnablers; aEnablerIndex++) {
                var aEnabler = this._v_Enablers[ aEnablerIndex];
                if( aEnabler.enablerName() == theEnablerName) {
                    return aEnabler;
                }
            }

            return null;
        };
        if( enablerByName) {} /* CQT */
        aPrototype.enablerByName = enablerByName;






        var enablerImmediateCreate = function( theEnablerName) {

            return this._enablerCreate( theEnablerName, theEnablerImmediateConstructor);
        };
        if( enablerImmediateCreate) {} /* CQT */
        aPrototype.enablerImmediateCreate = enablerImmediateCreate;





        var enablerProxyCreate = function( theEnablerName, theProxiedEnablerPaths) {

            var anEnabler = this._enablerCreate( theEnablerName, theEnablerProxyConstructor);
            anEnabler.proxiedEnablerPathsSet( theProxiedEnablerPaths);
        };
        if( enablerProxyCreate) {} /* CQT */
        aPrototype.enablerProxyCreate = enablerProxyCreate;





        var _enablerCreate = function( theEnablerName, theEnablerConstructor) {
            if( !theEnablerName || !theEnablerConstructor) {
                return null;
            }

            if( this.enablerByName( theEnablerName)) {
                return null;
            }

            var aEnabler = new theEnablerConstructor( theEnablerName);

            var someSavedEnablers    = this._v_Enablers.slice();

            try {
                aEnabler._activitySet_privileged( this);
                this._v_Enablers.push( aEnabler);
            }
            catch( anException) {
                this._v_Enablers = someSavedEnablers;
            }

            return aEnabler;
        };
        if( _enablerCreate) {} /* CQT */
        aPrototype._enablerCreate = _enablerCreate;






        var enablerRemove = function( theEnabler) {
            if( !theEnabler) {
                return;
            }

            var anEnablerIndex = this._v_Enablers.indexOf( theEnabler);
            if( anEnablerIndex < 0) {
                return;
            }


            var someSavedEnablers    = this._v_Enablers.slice();

            try {
                theEnabler._activityUnset_privileged();
                this._v_Enablers.splice( anEnablerIndex, 1);
            }
            catch( anException) {
                this._v_Enablers = someSavedEnablers;
            }
        };
        if( enablerRemove) {} /* CQT */
        aPrototype.enablerRemove = enablerRemove;





        return aPrototype;

    })( ChainedTypes.Chained.constructor,
        DataStoreTypes.DataStore.constructor,
        EnablerTypes.EnablerImmediate.constructor,
        EnablerTypes.EnablerProxy.constructor,
        EnablerTypes.EnablerDependency.constructor
    );









    /* Define constructor for instances with the prototype. */

    var Activity_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Chained = ChainedTypes.Chained.prototype;

        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_Choreography   = null;
        this._v_ParentActivity = null;
        this._v_DataStores     = null;
        this._v_Enablers       = null;

        this._pInit( theName);
    };
    Activity_Constructor.prototype = aActivity_Prototype;






    /* Expose component members */
    var someTypes = {
        "Module":        "ActivityTypes",
        "Activity": {
            prototype:   aActivity_Prototype,
            constructor: Activity_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);











