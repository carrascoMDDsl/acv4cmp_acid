'use strict';

/*
 * choreography/activitysimple_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */


var mModule = angular.module("activitySimpleTypes", []);



mModule.factory("ActivitySimpleTypes", [
    "ActivityTypes",
function( ActivityTypes){






    /* ******************************************************************************
     TYPE  Choreography.ActivitySimple
     */

    /* Define prototype. Inherits from another prototype */
    var aActivitySimple_Prototype = (function(
        theSuperConstructor) {



        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "ActivitySimple";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */

        aPrototype._v_Behaviors   = null;





        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Activity._pInit.apply( this, [ theName]);

            this._v_Behaviors   = [ ];
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;








        
        /* ******************************************************************
         Behaviors contents.
         */


        var behaviors = function() {

            return this._v_Behaviors.slice();
        };
        if( behaviors) {} /* CQT */
        aPrototype.behaviors = behaviors;





        var hasBehavior = function( theBehavior) {
            if( !theBehavior) {
                return false;
            }

            if( this._v_Behaviors.indexOf( theBehavior) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasBehavior) {} /* CQT */
        aPrototype.hasBehavior = hasBehavior;







        var behaviorsAdd = function( theBehavior) {
            if( !theBehavior) {
                return;
            }

            if( this.hasBehavior( theBehavior)) {
                return;
            }

            this._v_Behaviors.push( theBehavior);
        };
        if( behaviorsAdd) {} /* CQT */
        aPrototype.behaviorsAdd = behaviorsAdd;







        var behaviorsRemove = function( theBehavior) {
            if( !theBehavior) {
                return;
            }

            var anBehaviorIndex = this._v_Behaviors.indexOf( theBehavior);
            if( anBehaviorIndex < 0) {
                return;
            }

            this._v_Behaviors.splice( anBehaviorIndex, 1);
        };
        if( behaviorsRemove) {} /* CQT */
        aPrototype.behaviorsRemove = behaviorsRemove;












            return aPrototype;

    })( ActivityTypes.Activity.constructor);









    /* Define constructor for instances with the prototype. */

    var ActivitySimple_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Activity = ActivityTypes.Activity.prototype;

        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_Behaviors   = null;

        this._pInit( theName);
    };
    ActivitySimple_Constructor.prototype = aActivitySimple_Prototype;






    /* Expose component members */
    var someTypes = {
        "Module":        "ActivitySimpleTypes",
        "ActivitySimple": {
            prototype:   aActivitySimple_Prototype,
            constructor: ActivitySimple_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);











