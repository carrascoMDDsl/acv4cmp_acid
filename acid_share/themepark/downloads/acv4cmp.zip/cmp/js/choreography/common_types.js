'use strict';

/*
 * choreography/common_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero.
 *
 * 2014/03/21
 *
 */



var mModule = angular.module("choreographyCommonTypes", []);



mModule.factory("ChoreographyCommonTypes", [
function(){




    /* ******************************************************************************
     TYPE  Choreography.Common
     */


    /* Define prototype. Has no prototype inheritance itself */
    var aCommon_Prototype = (function() {

        /* Configurable constants */




        /* Internal constants */



        var aPrototype = {};
        aPrototype._v_Package= "Choreography";
        aPrototype._v_Type   = "Common";
        aPrototype._v_Kind   = "Type";
        aPrototype._v_Layer  = "Object";


        /* Prototype member properties */





        /* Supply essential contextual parameters */
        var _pInit = function() {

        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;




        var typePackage = function() {

            return this._v_Package;
        };
        if( typePackage) {} /* CQT */
        aPrototype.typePackage = typePackage;




        var typeName = function() {

            return this._v_Type;
        };
        if( typeName) {} /* CQT */
        aPrototype.typeName = typeName;






        var typeKind = function() {

            return this._v_Kind;
        };
        if( typeKind) {} /* CQT */
        aPrototype.typeKind = typeKind;





        var typeLayer = function() {

            return this._v_Layer;
        };
        if( typeLayer) {} /* CQT */
        aPrototype.typeLayer = typeLayer;




        return aPrototype;

    })();







    /* Define constructor for instances with the prototype. */

    var Common_Constructor = function() {

        /* Init object layout with member properties ASAP for the benefit of JIT */

        this._pInit();
    };
    Common_Constructor.prototype = aCommon_Prototype;




    /* Expose component members */
    var someTypes = {
        "Module":        "ChoreographyCommonTypes",
        "Common": {
            prototype:   aCommon_Prototype,
            constructor: Common_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);










