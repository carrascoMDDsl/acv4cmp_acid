'use strict';

/*
 * choreography/activitycomposite_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */


var mModule = angular.module("activityCompositeTypes", []);



mModule.factory("ActivityCompositeTypes", [
    "ActivityTypes",
    "BeginAndOutcomeTypes",
    "ActivitySimpleTypes",
    "ActivityInteractiveTypes",
    "ChainedTypes",
function(
    ActivityTypes,
    BeginAndOutcomeTypes,
    ActivitySimpleTypes,
    ActivityInteractiveTypes,
    ChainedTypes
){



    /* Define constructor for instances with the prototype.
    * CONSTRUCTOR DEFINED BEFORE THE PROTOTYPE BECAUSE IT IS NEEDED TO CONSTRUCT
    * SUB ACTIVITIES COMPOSITE.
    * THE CONSTRUCTOR GETS ASSIGNED THE .prototype after the
    * declaration and evaluation of aActivityComposite_Prototype */


    var ActivityComposite_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Activity = ActivityTypes.Activity.prototype;

        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_SubActivities     = null;
        this._v_InitialActivities = null;
        this._v_Outcomes          = null;
        this._v_Chains            = null;

        this._pInit( theName);
    };



    /* ******************************************************************************
     TYPE  Choreography.ActivityComposite
     */

    /* Define prototype. Inherits from another prototype */
    var aActivityComposite_Prototype = (function(
        theSuperConstructor,
        theBeginConstructor,
        theOutcomeConstructor,
        theOutcomeSuccessConstructor,
        theOutcomeFailureConstructor,
        theActivitySimpleConstructor,
        theActivityRequestReplyConstructor,
        theActivityCompositeConstructor,
        theChainConstructor
        ) {



        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "ActivityComposite";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */

        aPrototype._v_SubActivities     = null;
        aPrototype._v_InitialActivities = null;
        aPrototype._v_Outcomes          = null;
        aPrototype._v_Chains            = null;




        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Activity._pInit.apply( this, [ theName]);

            this._v_SubActivities     = [ ];
            this._v_InitialActivities = [ ];
            this._v_Outcomes          = [ ];
            this._v_Chains            = [ ];
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;








        /* ******************************************************************
         SubActivities aggregation contents. Also Begins.
        */


        var subActivities = function() {

            return this._v_SubActivities.slice();
        };
        if( subActivities) {} /* CQT */
        aPrototype.subActivities = subActivities;




        var hasSubActivity = function( theActivity) {
            if( !theActivity) {
                return false;
            }

            if( this._v_SubActivities.indexOf( theActivity) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasSubActivity) {} /* CQT */
        aPrototype.hasSubActivity = hasSubActivity;






        var subActivityByName = function( theSubActivityName) {
            if( !theSubActivityName) {
                return null;
            }

            var aNumSubActivities = this._v_SubActivities.length;
            if( !aNumSubActivities) {
                return null;
            }

            for( var aSubActivityIndex = 0; aSubActivityIndex < aNumSubActivities; aSubActivityIndex++) {
                var aSubActivity = this._v_SubActivities[ aSubActivityIndex];
                if( aSubActivity.activityName() == theSubActivityName) {
                    return aSubActivity;
                }
            }

            return null;
        };
        if( subActivityByName) {} /* CQT */
        aPrototype.subActivityByName = subActivityByName;





        var hasSubActivityNamed = function( theSubActivityName) {
            if( !theSubActivityName) {
                return false;
            }

            var aSubActivity = this.subActivityByName( theSubActivityName);
            if( !aSubActivity) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasSubActivityNamed) {} /* CQT */
        aPrototype.hasSubActivityNamed = hasSubActivityNamed;







        var beginCreate = function( theBeginName) {

            var aBegin = this._subActivityCreate( theBeginName, theBeginConstructor);
            this.initialActivitiesAdd( aBegin);
        };
        if( beginCreate) {} /* CQT */
        aPrototype.beginCreate = beginCreate;








        var subActivitySimpleCreate = function( theSubActivityName) {

            return this._subActivityCreate( theSubActivityName, theActivitySimpleConstructor);
        };
        if( subActivitySimpleCreate) {} /* CQT */
        aPrototype.subActivitySimpleCreate = subActivitySimpleCreate;





        var subActivityRequestReplyCreate = function( theSubActivityName) {

            return this._subActivityCreate( theSubActivityName, theActivityRequestReplyConstructor);
        };
        if( subActivityRequestReplyCreate) {} /* CQT */
        aPrototype.subActivityRequestReplyCreate = subActivityRequestReplyCreate;




        var subActivityCompositeCreate = function( theSubActivityName) {

            return this._subActivityCreate( theSubActivityName, theActivityCompositeConstructor);
        };
        if( subActivityCompositeCreate) {} /* CQT */
        aPrototype.subActivityCompositeCreate = subActivityCompositeCreate;











        var outcomeCreate = function( theOutcomeName) {

            var anOutcome = this._subActivityCreate( theOutcomeName, theOutcomeConstructor);
            this._outcomesAdd( anOutcome);
            return anOutcome;
        };
        if( outcomeCreate) {} /* CQT */
        aPrototype.outcomeCreate = outcomeCreate;





        var outcomeSuccessCreate = function( theOutcomeName) {

            var aSuccess = this._subActivityCreate( theOutcomeName, theOutcomeSuccessConstructor);
            this._outcomesAdd( aSuccess);
            return aSuccess;
        };
        if( outcomeSuccessCreate) {} /* CQT */
        aPrototype.outcomeSuccessCreate = outcomeSuccessCreate;





        var outcomeFailureCreate = function( theOutcomeName) {

            var aFailure = this._subActivityCreate( theOutcomeName, theOutcomeFailureConstructor);
            this._outcomesAdd( aFailure);
            return aFailure;
        };
        if( outcomeFailureCreate) {} /* CQT */
        aPrototype.outcomeFailureCreate = outcomeFailureCreate;





        var _subActivityCreate = function( theSubActivityName, theSubActivityConstructor) {
            if( !theSubActivityName || !theSubActivityConstructor) {
                return null;
            }

            if( this.subActivityByName( theSubActivityName)) {
                return null;
            }

            var aSubActivity = new theSubActivityConstructor( theSubActivityName);

            var someSavedSubActivities    = this._v_SubActivities.slice();

            try {
                aSubActivity._parentActivitySet_privileged( this);
                this._v_SubActivities.push( aSubActivity);
            }
            catch( anException) {
                this._v_SubActivities = someSavedSubActivities;
            }

            return aSubActivity;
        };
        if( _subActivityCreate) {} /* CQT */
        aPrototype._subActivityCreate = _subActivityCreate;





        var subActivityRemove = function( theSubActivity) {
            if( !theSubActivity) {
                return;
            }

            var aSubActivityIndex = this._v_SubActivities.indexOf( theSubActivity);
            if( aSubActivityIndex < 0) {
                return;
            }

            var someSavedSubActivities    = this._v_SubActivities.slice();

            try {
                theSubActivity._parentActivityUnset_privileged();
                this._v_SubActivities.splice( aSubActivityIndex, 1);
            }
            catch( anException) {
                this._v_SubActivities = someSavedSubActivities;
            }
        };
        if( subActivityRemove) {} /* CQT */
        aPrototype.subActivityRemove = subActivityRemove;









        /* ******************************************************************
         Initial Activities references.
        */


        var initialActivities = function() {

            return this._v_InitialActivities.slice();
        };
        if( initialActivities) {} /* CQT */
        aPrototype.initialActivities = initialActivities;





        var hasInitialActivity = function( theActivity) {
            if( !theActivity) {
                return false;
            }

            if( this._v_InitialActivities.indexOf( theActivity) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasInitialActivity) {} /* CQT */
        aPrototype.hasInitialActivity = hasInitialActivity;




        var initialActivityNamed = function( theActivityName) {
            if( !theActivityName) {
                return false;
            }

            var aNumInitialActivities = this._v_InitialActivities.length;
            if( !aNumInitialActivities) {
                return null;
            }

            for( var anInitialActivityIndex = 0; anInitialActivityIndex < aNumInitialActivities; anInitialActivityIndex++) {
                var anInitialActivity = this._v_InitialActivities[ anInitialActivityIndex];
                if( anInitialActivity.activityName() == theActivityName) {
                    return anInitialActivity;
                }
            }

            return null;
        };
        if( initialActivityNamed) {} /* CQT */
        aPrototype.initialActivityNamed = initialActivityNamed;





        var hasInitialActivityNamed = function( theActivityName) {
            if( !theActivityName) {
                return false;
            }

            var anInitialActivity = this.initialActivityNamed( theActivityName);
            if( !anInitialActivity) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasInitialActivityNamed) {} /* CQT */
        aPrototype.hasInitialActivityNamed = hasInitialActivityNamed;





        var initialActivitiesAdd = function( theActivity) {
            if( !theActivity) {
                return;
            }

            if( !this.hasSubActivity( theActivity)) {
                return;
            }

            if( this.hasInitialActivity( theActivity)) {
                return;
            }

            this._v_InitialActivities.push( theActivity);
        };
        if( initialActivitiesAdd) {} /* CQT */
        aPrototype.initialActivitiesAdd = initialActivitiesAdd;





        var initialActivitiesRemove = function( theActivity) {
            if( !theActivity) {
                return;
            }

            var aSubActivityIndex = this._v_InitialActivities.indexOf( theActivity);
            if( aSubActivityIndex < 0) {
                return;
            }

            this._v_InitialActivities.splice( aSubActivityIndex, 1);
        };
        if( initialActivitiesRemove) {} /* CQT */
        aPrototype.initialActivitiesRemove = initialActivitiesRemove;










        /* ******************************************************************
         Outcomes references.
         */


        var outcomes = function() {

            return this._v_Outcomes.slice();
        };
        if( outcomes) {} /* CQT */
        aPrototype.outcomes = outcomes;





        var hasOutcome = function( theOutcome) {
            if( !theOutcome) {
                return false;
            }

            if( this._v_Outcomes.indexOf( theOutcome) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasOutcome) {} /* CQT */
        aPrototype.hasOutcome = hasOutcome;




        var outcomeNamed = function( theOutcomeName) {
            if( !theOutcomeName) {
                return false;
            }

            var aNumOutcomes = this._v_Outcomes.length;
            if( !aNumOutcomes) {
                return null;
            }

            for( var anOutcomeIndex = 0; anOutcomeIndex < aNumOutcomes; anOutcomeIndex++) {
                var anOutcome = this._v_Outcomes[ anOutcomeIndex];
                if( anOutcome.activityName() == theOutcomeName) {
                    return anOutcome;
                }
            }

            return null;
        };
        if( outcomeNamed) {} /* CQT */
        aPrototype.outcomeNamed = outcomeNamed;





        var hasOutcomeNamed = function( theOutcomeName) {
            if( !theOutcomeName) {
                return false;
            }

            var anOutcome = this.outcomeNamed( theOutcomeName);
            if( !anOutcome) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasOutcomeNamed) {} /* CQT */
        aPrototype.hasOutcomeNamed = hasOutcomeNamed;






        var _outcomesAdd = function( theOutcome) {
            if( !theOutcome) {
                return;
            }

            if( !this.hasSubActivity( theOutcome)) {
                return;
            }

            if( this.hasOutcome( theOutcome)) {
                return;
            }

            this._v_Outcomes.push( theOutcome);
        };
        if( _outcomesAdd) {} /* CQT */
        aPrototype._outcomesAdd = _outcomesAdd;





        var outcomesRemove = function( theOutcome) {
            if( !theOutcome) {
                return;
            }

            var anOutcomeIndex = this._v_Outcomes.indexOf( theOutcome);
            if( anOutcomeIndex < 0) {
                return;
            }

            this._v_Outcomes.splice( anOutcomeIndex, 1);
        };
        if( outcomesRemove) {} /* CQT */
        aPrototype.outcomesRemove = outcomesRemove;















        /* ******************************************************************
         Chains aggregation contents.
         */


        var chains = function() {

            return this._v_Chains.slice();
        };
        if( chains) {} /* CQT */
        aPrototype.chains = chains;






        var chainsFrom = function( theChained) {
            var someChains = [];

            if( !theChained) {
                return someChains;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessor( theChained)) {
                    someChains.push( aChain);
                }
            }

            return someChains;
        };
        if( chainsFrom) {} /* CQT */
        aPrototype.chainsFrom = chainsFrom;





        var chainsTo = function( theChained) {
            var someChains = [];

            if( !theChained) {
                return someChains;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasSuccessor( theChained)) {
                    someChains.push( aChain);
                }
            }

            return someChains;
        };
        if( chainsTo) {} /* CQT */
        aPrototype.chainsTo = chainsTo;





        var chainsFromOrTo = function( theChained) {
            var someChains = [];

            if( !theChained) {
                return someChains;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessor( theChained) || aChain.hasSuccessor( theChained)) {
                    someChains.push( aChain);
                }
            }

            return someChains;
        };
        if( chainsFromOrTo) {} /* CQT */
        aPrototype.chainsFromOrTo = chainsFromOrTo;





        var chainsFromTo = function( thePredecessorChained, theSuccessorChained, theGuard) {
            var someChains = [];

            if( !thePredecessorChained || !theSuccessorChained) {
                return someChains;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessor( thePredecessorChained) && aChain.hasSuccessor( theSuccessorChained)) {
                    if( !theGuard || ( aChain.guard() == theGuard)) {
                        someChains.push( aChain);
                    }
                }
            }

            return someChains;
        };
        if( chainsFromTo) {} /* CQT */
        aPrototype.chainsFromTo = chainsFromTo;






        var chainsFromNamed = function( theChainedName) {
            var someChains = [];

            if( !theChainedName) {
                return someChains;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessorNamed( theChainedName)) {
                    someChains.push( aChain);
                }
            }

            return someChains;
        };
        if( chainsFromNamed) {} /* CQT */
        aPrototype.chainsFromNamed = chainsFromNamed;




        var chainsToNamed = function( theChainedName) {
            var someChains = [];

            if( !theChainedName) {
                return someChains;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasSuccessorNamed( theChainedName)) {
                    someChains.push( aChain);
                }
            }

            return someChains;
        };
        if( chainsToNamed) {} /* CQT */
        aPrototype.chainsToNamed = chainsToNamed;






        var chainsFromOrToNamed = function( theChainedName) {
            var someChains = [];

            if( !theChainedName) {
                return someChains;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessorNamed( theChainedName) || ( aChain.hasSuccessorNamed( theChainedName))) {
                    someChains.push( aChain);
                }
            }

            return someChains;
        };
        if( chainsFromOrToNamed) {} /* CQT */
        aPrototype.chainsFromOrToNamed = chainsFromOrToNamed;






        var chainsFromToNamed = function( thePredecessorChainedName, theSuccessorChainedName, theGuard) {
            var someChains = [];

            if( !thePredecessorChainedName || !theSuccessorChainedName) {
                return someChains;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessorNamed( thePredecessorChainedName) &&
                    aChain.hasSuccessorNamed( theSuccessorChainedName)) {
                    if( !theGuard || ( aChain.guard() == theGuard)) {
                        someChains.push( aChain);
                    }
                }
            }

            return someChains;
        };
        if( chainsFromToNamed) {} /* CQT */
        aPrototype.chainsFromToNamed = chainsFromToNamed;







        var hasChain = function( theChain) {
            if( !theChain) {
                return false;
            }

            if( this._v_Chains.indexOf( theChain) < 0) {
                var a = null; if( a) {} /* CQT */
                return false;
            }

            return true;
        };
        if( hasChain) {} /* CQT */
        aPrototype.hasChain = hasChain;






        var hasChainFrom = function( theChained) {
            if( !theChained) {
                return false;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessor( theChained)) {
                    return true;
                }
            }

            return false;
        };
        if( hasChainFrom) {} /* CQT */
        aPrototype.hasChainFrom = hasChainFrom;





        var hasChainTo = function( theChained) {
            if( !theChained) {
                return false;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasSuccessor( theChained)) {
                    return true;
                }
            }

            return false;
        };
        if( hasChainTo) {} /* CQT */
        aPrototype.hasChainTo = hasChainTo;





        var hasChainFromOrTo = function( theChained) {
            if( !theChained) {
                return false;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessor( theChained) || aChain.hasSuccessor( theChained)) {
                    return true;
                }
            }

            return false;
        };
        if( hasChainFromOrTo) {} /* CQT */
        aPrototype.hasChainFromOrTo = hasChainFromOrTo;





        var hasChainFromTo = function( thePredecessorChained, theSuccessorChained, theGuard) {
            if( !thePredecessorChained || !theSuccessorChained) {
                return false;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessor( thePredecessorChained) && aChain.hasSuccessor( theSuccessorChained)) {
                    if( !theGuard || ( aChain.guard() == theGuard)) {
                        return true;
                    }
                }
            }

            return false;
        };
        if( hasChainFromTo) {} /* CQT */
        aPrototype.hasChainFromTo = hasChainFromTo;






        var hasChainFromNamed = function( theChainedName) {
            if( !theChainedName) {
                return false;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessorNamed( theChainedName)) {
                    return true;
                }
            }

            return false;
        };
        if( hasChainFromNamed) {} /* CQT */
        aPrototype.hasChainFromNamed = hasChainFromNamed;




        var hasChainToNamed = function( theChainedName) {
            if( !theChainedName) {
                return false;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasSuccessorNamed( theChainedName)) {
                    return true;
                }
            }

            return false;
        };
        if( hasChainToNamed) {} /* CQT */
        aPrototype.hasChainToNamed = hasChainToNamed;






        var hasChainFromOrToNamed = function( theChainedName) {
            if( !theChainedName) {
                return false;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessorNamed( theChainedName) || ( aChain.hasSuccessorNamed( theChainedName))) {
                    return true;
                }
            }

            return false;
        };
        if( hasChainFromOrToNamed) {} /* CQT */
        aPrototype.hasChainFromOrToNamed = hasChainFromOrToNamed;






        var hasChainFromToNamed = function( thePredecessorChainedName, theSuccessorChainedName, theGuard) {
            if( !thePredecessorChainedName || !theSuccessorChainedName) {
                return false;
            }

            var aNumChains = this._v_Chains.length;
            for( var aChainIndex = 0; aChainIndex < aNumChains; aChainIndex++) {
                var aChain = this._v_Chains[ aChainIndex];
                if( aChain.hasPredecessorNamed( thePredecessorChainedName) &&
                    aChain.hasSuccessorNamed( theSuccessorChainedName)) {
                    if( !theGuard || ( aChain.guard() == theGuard)) {
                        return true;
                    }
                }
            }

            return false;
        };
        if( hasChainFromToNamed) {} /* CQT */
        aPrototype.hasChainFromToNamed = hasChainFromToNamed;










        var chainCreate = function( thePredecessor, theSuccessor, theGuard) {
            if( !thePredecessor || !theSuccessor) {
                return null;
            }

            if( this.hasChainFromTo( thePredecessor, theSuccessor, theGuard)) {
                return null;
            }

            var aChain = new theChainConstructor( thePredecessor, theSuccessor, theGuard);

            var someSavedChains                  = this._v_Chains.slice();
            var aPredecessorSavedSuccesorChains  = thePredecessor._v_SuccessorChains.slice();
            var aSuccesorSavedPredecessorChains  = theSuccessor._v_PredecessorChains.slice();

            try {
                aChain._parentChainSet_privileged( this);
                this._v_Chains.push( aChain);

                thePredecessor.successorChainAdd_privileged( aChain);
                theSuccessor.predecessorChainAdd_privileged( aChain);
            }
            catch( anException) {
                this._v_Chains = someSavedChains;
                thePredecessor._v_SuccessorChain  = aPredecessorSavedSuccesorChains;
                theSuccessor._v_PredecessorChains = aSuccesorSavedPredecessorChains;
            }

            return aChain;
        };
        if( chainCreate) {} /* CQT */
        aPrototype.chainCreate = chainCreate;





        var chainRemove = function( theChain) {
            if( !theChain) {
                return;
            }

            var aChainIndex = this._v_Chains.indexOf( theChain);
            if( aChainIndex < 0) {
                return;
            }

            var someSavedChains    = this._v_Chains.slice();

            var somePredecessors = theChain.predecessors();
            var aNumPredecessors = somePredecessors.length;

            var someSuccessors   = theChain.successors();
            var aNumSuccessors   = someSuccessors.length;

            var somePredecessorSavedSuccesorChains = somePredecessors.map( function( theChained) {
                return [ theChained, theChained._v_SuccessorChains.slice()];
            });
            var someSuccessorSavedPredecessorChains = someSuccessors.map( function( theChained) {
                return [ theChained, theChained._v_PredecessorChains.slice()];
            });

            try {
                theChain._parentChainUnset_privileged();
                this._v_Chains.splice( aChainIndex, 1);

                for( var anIndex = 0; anIndex < aNumPredecessors; anIndex++) {
                    var aPredecessor = somePredecessors[ anIndex];
                    aPredecessor.successorChainRemove_privileged( theChain);
                }

                for( var anIndex = 0; anIndex < aNumSuccessors; anIndex++) {
                    var aSuccessor = somePredecessors[ anIndex];
                    aSuccessor.predecessorChainRemove_privileged( theChain);
                }
            }
            catch( anException) {
                this._v_Chains = someSavedChains;

                for( var anIndex = 0; anIndex < aNumPredecessors; anIndex++) {
                    var aPredecessorAndSavedChains = somePredecessorSavedSuccesorChains[ anIndex];
                    aPredecessorAndSavedChains[ 0]._v_SuccessorChains = aPredecessorAndSavedChains[ 1];
                }

                for( var anIndex = 0; anIndex < aNumSuccessors; anIndex++) {
                    var aSuccessorAndSavedChains = someSuccessorSavedPredecessorChains[ anIndex];
                    aSuccessorAndSavedChains[ 0]._v_PredecessorChains = aSuccessorAndSavedChains[ 1];
                }
            }
        };
        if( chainRemove) {} /* CQT */
        aPrototype.chainRemove = chainRemove;






        return aPrototype;

    })( ActivityTypes.Activity.constructor,
        BeginAndOutcomeTypes.Begin.constructor,
        BeginAndOutcomeTypes.Outcome.constructor,
        BeginAndOutcomeTypes.Success.constructor,
        BeginAndOutcomeTypes.Failure.constructor,
        ActivitySimpleTypes.ActivitySimple.constructor,
        ActivityInteractiveTypes.ActivityRequestReply.constructor,
        ActivityComposite_Constructor,
        ChainedTypes.Chain.constructor
    );




    /* CONSTRUCTOR DEFINED BEFORE THE PROTOTYPE BECAUSE IT IS NEEDED TO CONSTRUCT
     * SUB ACTIVITIES COMPOSITE.
     * THE CONSTRUCTOR GETS ASSIGNED THE .prototype after the
     * declaration and evaluation of aActivityComposite_Prototype
    */
    ActivityComposite_Constructor.prototype = aActivityComposite_Prototype;






    /* Expose component members */
    var someTypes = {
        "Module":        "ActivityCompositeTypes",
        "ActivityComposite": {
            prototype:   aActivityComposite_Prototype,
            constructor: ActivityComposite_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);











