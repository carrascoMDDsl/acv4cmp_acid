'use strict';

/*
 * choreography/choreography_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */

var mModule = angular.module("choreographyTypes", []);



mModule.factory("ChoreographyTypes", [
    "ChoreographySpecificationCommonTypes",
    "ActivitySimpleTypes",
    "ActivityInteractiveTypes",
    "ActivityCompositeTypes",
function(
    ChoreographySpecificationCommonTypes,
    ActivitySimpleTypes,
    ActivityInteractiveTypes,
    ActivityCompositeTypes
    ){




    /* ******************************************************************************
     TYPE  Choreography.Choreography
     */

    /* Define prototype. Inherits from another prototype */
    var aChoreography_Prototype = (function(
        theSuperConstructor,
        theActivitySimpleConstructor,
        theActivityRequestReplyConstructor,
        theActivityReceiveRespondConstructor,
        theActivityCompositeConstructor
        ) {

        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Choreography";
        aPrototype._v_Type    = "Choreography";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */


        aPrototype._v_Activity = null;



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_NamedSpecification._pInit.apply( this, [ theName]);

            this._v_Activity = null;
            if( this._v_Activity) {} /* CQT */
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;





        var choreographyName = function() {

            /* Delegate on super prototype */
            return this._v_SuperPrototype_NamedSpecification.instanceName.apply( this);
        };
        if( choreographyName) {} /* CQT */
        aPrototype.choreographyName = choreographyName;





        var activity = function() {

            return this._v_Activity;
        };
        if( activity) {} /* CQT */
        aPrototype.activity = activity;






        var activitySimpleCreate = function( theActivityName) {

            return this._activityCreate( theActivityName, theActivitySimpleConstructor);
        };
        if( activitySimpleCreate) {} /* CQT */
        aPrototype.activitySimpleCreate = activitySimpleCreate;




        var activityRequestReplyCreate = function( theActivityName) {

            return this._activityCreate( theActivityName, theActivityRequestReplyConstructor);
        };
        if( activityRequestReplyCreate) {} /* CQT */
        aPrototype.activityRequestReplyCreate = activityRequestReplyCreate;





        var activityReceiveRespondCreate = function( theActivityName) {

            return this._activityCreate( theActivityName, theActivityReceiveRespondConstructor);
        };
        if( activityReceiveRespondCreate) {} /* CQT */
        aPrototype.activityReceiveRespondCreate = activityReceiveRespondCreate;





        var activityCompositeCreate = function( theActivityName) {

            return this._activityCreate( theActivityName, theActivityCompositeConstructor);
        };
        if( activityCompositeCreate) {} /* CQT */
        aPrototype.activityCompositeCreate = activityCompositeCreate;





        var _activityCreate = function( theActivityName, theActivityConstructor) {
            if( !theActivityName || !theActivityConstructor) {
                return null;
            }

            if( this._v_Activity) {
                return null;
            }

            var anActivityName = theActivityName;
            if( !anActivityName) {
                anActivityName = this.choreographyName() + "-Top";
            }

            var anActivity = new theActivityConstructor( anActivityName);

            var aSavedActivity    = this._v_Activity;

            try {
                anActivity._choreographySet_privileged( this);
                this._v_Activity = anActivity;
            }
            catch( anException) {
                this._v_Activity = aSavedActivity;
            }

            return anActivity;
        };
        if( _activityCreate) {} /* CQT */
        aPrototype._activityCreate = _activityCreate;





        return aPrototype;

    })( ChoreographySpecificationCommonTypes.NamedSpecification.constructor,
            ActivitySimpleTypes.ActivitySimple.constructor,
            ActivityInteractiveTypes.ActivityRequestReply.constructor,
            ActivityInteractiveTypes.ActivityReceiveRespond.constructor,
            ActivityCompositeTypes.ActivityComposite.constructor
        );







    /* Define constructor for instances with the prototype. */

    var Choreography_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_NamedSpecification = ChoreographySpecificationCommonTypes.NamedSpecification.prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_Activity = null;

        this._pInit( theName);
    };
    Choreography_Constructor.prototype = aChoreography_Prototype;










    /* Expose component members */
    var someTypes = {
        "Module":        "ChoreographyTypes",
        "Choreography": {
            prototype:   aChoreography_Prototype,
            constructor: Choreography_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);










