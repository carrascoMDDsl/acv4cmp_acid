'use strict';

/*
 * activity/enabler_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */


var mModule = angular.module("enablerTypes", []);



mModule.factory("EnablerTypes", [
    "ChoreographySpecificationCommonTypes",
function( ChoreographySpecificationCommonTypes){






    /* ******************************************************************************
     TYPE  Activity.Enabler
     */

    /* Define prototype. Inherits from another prototype */
    var aEnabler_Prototype = (function( theSuperConstructor) {

        if( theSuperConstructor) {} /* CQT mistake */


        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Activity";
        aPrototype._v_Type    = "Enabler";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */


        aPrototype._v_Activity   = null;



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_NamedSpecification._pInit.apply( this, [ theName]);

            this._v_Activity   = null;
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;





        var enablerName = function() {

            /* Delegate on super prototype */
            return this._v_SuperPrototype_NamedSpecification.instanceName.apply( this);
        };
        if( enablerName) {} /* CQT */
        aPrototype.enablerName = enablerName;






        /* ******************************************************************
         Activity aggregation container.
        */

        var activity = function() {

            if( this._v_Activity) {
                return this._v_Activity;
            }

            return null;
        };
        if( activity) {} /* CQT */
        aPrototype.activity = activity;






        var _activitySet_privileged = function( theActivity) {

            if( !theActivity) {
                return;
            }

            this._v_Activity   = theActivity;
        };
        if( _activitySet_privileged) {} /* CQT */
        aPrototype._activitySet_privileged = _activitySet_privileged;






        var _activityUnset_privileged = function() {

            this._v_Activity   = null;
        };
        if( _activityUnset_privileged) {} /* CQT */
        aPrototype._activityUnset_privileged = _activityUnset_privileged;




        return aPrototype;

    })( ChoreographySpecificationCommonTypes.NamedSpecification.constructor);









    /* Define constructor for instances with the prototype. */

    var Enabler_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_NamedSpecification = ChoreographySpecificationCommonTypes.NamedSpecification.prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_Activity   = null;

        this._pInit( theName);
    };
    Enabler_Constructor.prototype = aEnabler_Prototype;










    /* ******************************************************************************
     TYPE  Activity.EnablerImmediate
     */

    /* Define prototype. Inherits from another prototype */
    var aEnablerImmediate_Prototype = (function( theSuperConstructor) {

         if( theSuperConstructor) {} /* CQT mistake */

        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Activity";
        aPrototype._v_Type    = "EnablerImmediate";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */




        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Enabler._pInit.apply( this, [ theName]);
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;




        return aPrototype;

    })( Enabler_Constructor);







    /* Define constructor for instances with the prototype. */

    var EnablerImmediate_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Enabler = aEnabler_Prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */

        this._pInit( theName);
    };
    EnablerImmediate_Constructor.prototype = aEnablerImmediate_Prototype;













    /* ******************************************************************************
     TYPE  Activity.EnablerProxy
     */

    /* Define prototype. Inherits from another prototype */
    var aEnablerProxy_Prototype = (function( theSuperConstructor) {

        if( theSuperConstructor) {} /* CQT mistake */


        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Activity";
        aPrototype._v_Type    = "EnablerProxy";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */


        aPrototype._v_ProxiedEnablerPaths  = null;



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_Enabler._pInit.apply( this, [ theName]);

            this._v_ProxiedEnablerPaths   = null;
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;






        var proxiedEnablerPaths = function( ) {

            return this._v_ProxiedEnablerPaths;
        };
        if( proxiedEnablerPaths) {} /* CQT */
        aPrototype.proxiedEnablerPaths = proxiedEnablerPaths;




        var proxiedEnablerPathsSet = function( theProxiedEnablerPaths) {

            this._v_ProxiedEnablerPaths = theProxiedEnablerPaths;
        };
        if( proxiedEnablerPathsSet) {} /* CQT */
        aPrototype.proxiedEnablerPathsSet = proxiedEnablerPathsSet;




        var proxiedEnablerPathsUnset = function() {

            this._v_ProxiedEnablerPaths = null;
        };
        if( proxiedEnablerPathsUnset) {} /* CQT */
        aPrototype.proxiedEnablerPathsUnset = proxiedEnablerPathsUnset;




        return aPrototype;

    })( Enabler_Constructor);







    /* Define constructor for instances with the prototype. */

    var EnablerProxy_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_Enabler = aEnabler_Prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_ProxiedEnablerPaths   = null;

        this._pInit( theName);
    };
    EnablerProxy_Constructor.prototype = aEnablerProxy_Prototype;










    /* ******************************************************************************
     TYPE  Activity.EnablerDependency
     */

    /* Define prototype. Inherits from another prototype */
    var aEnablerDependency_Prototype = (function( theSuperConstructor) {

        if( theSuperConstructor) {} /* CQT mistake */


        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Activity";
        aPrototype._v_Type    = "EnablerDependency";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */


        aPrototype._v_Enabler   = null;
        aPrototype._v_Suppliers = null;
        aPrototype._v_Condition = null;



        /* Supply essential contextual parameters */
        var _pInit = function( theName, theCondition) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_NamedSpecification._pInit.apply( this, [ theName]);

            this._v_Enabler   = null;
            this._v_Suppliers = null;
            this._v_Condition = null;
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;





        var enablerName = function() {

            /* Delegate on super prototype */
            return this._v_SuperPrototype_NamedSpecification.instanceName.apply( this);
        };
        if( enablerName) {} /* CQT */
        aPrototype.enablerName = enablerName;






        /* ******************************************************************
         Enabler aggregation container.
         */

        var enabler = function() {

            if( this._v_Enabler) {
                return this._v_Enabler;
            }

            return null;
        };
        if( enabler) {} /* CQT */
        aPrototype.enabler = enabler;






        var _enablerSet_privileged = function( theEnabler) {

            if( !theEnabler) {
                return;
            }

            this._v_Enabler   = theEnabler;
        };
        if( _enablerSet_privileged) {} /* CQT */
        aPrototype._enablerSet_privileged = _enablerSet_privileged;






        var _enablerUnset_privileged = function() {

            this._v_Enabler   = null;
        };
        if( _enablerUnset_privileged) {} /* CQT */
        aPrototype._enablerUnset_privileged = _enablerUnset_privileged;






        return aPrototype;

    })( ChoreographySpecificationCommonTypes.NamedSpecification.constructor);









    /* Define constructor for instances with the prototype. */

    var EnablerDependency_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_NamedSpecification = ChoreographySpecificationCommonTypes.NamedSpecification.prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */

        this._pInit( theName);
    };
    EnablerDependency_Constructor.prototype = aEnablerDependency_Prototype;








    /* Expose component members */
    var someTypes = {
        "Module":        "EnablerTypes",
        "Enabler": {
            prototype:   aEnabler_Prototype,
            constructor: Enabler_Constructor
        },
        "EnablerImmediate": {
            prototype:   aEnablerImmediate_Prototype,
            constructor: EnablerImmediate_Constructor
        },
        "EnablerProxy": {
            prototype:   aEnablerProxy_Prototype,
            constructor: EnablerProxy_Constructor
        },
        "EnablerDependency": {
            prototype:   aEnablerDependency_Prototype,
            constructor: EnablerDependency_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);











