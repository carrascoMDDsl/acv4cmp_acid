'use strict';

/*
 * activity/dataStore_types.js
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 *
 * 2014/03/21
 *
 */


var mModule = angular.module("dataStoreTypes", []);



mModule.factory("DataStoreTypes", [
    "ChoreographySpecificationCommonTypes",
function( ChoreographySpecificationCommonTypes){






    /* ******************************************************************************
     TYPE  Activity.DataStore
     */

    /* Define prototype. Inherits from another prototype */
    var aDataStore_Prototype = (function( theSuperConstructor) {



        /* Configurable constants */




        /* Internal constants */


        var aPrototype = new theSuperConstructor();
        aPrototype._v_Package = "Activity";
        aPrototype._v_Type    = "DataStore";
        aPrototype._v_Kind    = "Type";
        aPrototype._v_Layer   = "Object";



        /* Prototype member properties */


        aPrototype._v_Activity   = null;



        /* Supply essential contextual parameters */
        var _pInit = function( theName) {

            /* Delegate on super prototype initialization */
            this._v_SuperPrototype_NamedSpecification._pInit.apply( this, [ theName]);

            this._v_Activity   = null;
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;





        var dataStoreName = function() {

            /* Delegate on super prototype */
            return this._v_SuperPrototype_NamedSpecification.instanceName.apply( this);
        };
        if( dataStoreName) {} /* CQT */
        aPrototype.dataStoreName = dataStoreName;






        /* ******************************************************************
         Activity aggregation container.
        */

        var activity = function() {

            if( this._v_Activity) {
                return this._v_Activity;
            }

            return null;
        };
        if( activity) {} /* CQT */
        aPrototype.activity = activity;






        var _activitySet_privileged = function( theActivity) {

            if( !theActivity) {
                return;
            }

            this._v_Activity   = theActivity;
        };
        if( _activitySet_privileged) {} /* CQT */
        aPrototype._activitySet_privileged = _activitySet_privileged;






        var _activityUnset_privileged = function() {

            this._v_Activity   = null;
        };
        if( _activityUnset_privileged) {} /* CQT */
        aPrototype._activityUnset_privileged = _activityUnset_privileged;








        return aPrototype;

    })( ChoreographySpecificationCommonTypes.NamedSpecification.constructor);









    /* Define constructor for instances with the prototype. */

    var DataStore_Constructor = function( theName) {

        /* Keep handy reference to super-prototype for super method invocation */
        this._v_SuperPrototype_NamedSpecification = ChoreographySpecificationCommonTypes.NamedSpecification.prototype;


        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_Activity   = null;

        this._pInit( theName);
    };
    DataStore_Constructor.prototype = aDataStore_Prototype;






    /* Expose component members */
    var someTypes = {
        "Module":        "DataStoreTypes",
        "DataStore": {
            prototype:   aDataStore_Prototype,
            constructor: DataStore_Constructor
        }
    };
    if( someTypes) {} /* CQT */
    return someTypes;


}]);











