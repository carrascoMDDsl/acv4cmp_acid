'use strict';

/*
 * obtainwaittimes_behaviors.js
 *
 * A Javascript exercise.
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 * 03/11/2014
 */



var mModulo = angular.module("waittimesBehaviorsSupplier", []);



mModulo.factory("WaitTimes_Behaviors", [  "$http", function( $http){

    /* ********************************************
    Login remote service invocation.
    Execute handlers in case of success or error.

    Return inmediately if a token is already available
    because login has already been performed with success.

    Else,
    Connect to server,  and
    if obtains access token then execute the success handler,
    which may quite possibly be in charge of starting the wait-times retrieval interval.
    (not that this service cares).
    */



    var fLogin_Behavior = function(  thePassword, theServiceURL, theApplicationId, theParkName, theDS_AccessToken) {

        if( this._v_DS_AccessToken && this._v_DS_AccessToken.value) {
            return true;
        }

        if( !thePassword) {
            return false;
        }

        if( !theServiceURL) {
            return false;
        }

        if( !theApplicationId) {
            return false;
        }

        if( !theParkName) {
            return false;
        }


        var aPayload = {
            "action": "login",
            "applicationId": this._v_ApplicationId,
            "password": thePassword,
            "park": this._v_ParkName
        };



        var aThis = this;



        /* Code below uses JQuery, which is included in the application for this sole purpose.
         Angular offers the service $http, which is easily dependency-injected by refering to it in this module's declaration.
         Angular also offers a subset of JQuery (I believe, the "core" selection rules matching of DOM elements),
         which is available under the same "$" when JQuery has not been also loaded in the application.
         */
        var aPayloadString = JSON.stringify( aPayload);

        var aPromise = $.ajax({
            type: "POST",
            url: this._v_ServiceURL,
            data: aPayloadString,
            success: function( theResponse) {
                aThis._pSuccess( theExecution, theResponse);
            }
        });

        aPromise.fail( function( theResponse) {
            aThis._pFailure( theExecution, theResponse);
        });
    };



    /* Define prototype. Has no prototype inheritance itself */
    var aLogin_Behavior_Prototype = (function() {

        var aPrototype = {};
        aPrototype._v_Package = "ThemePark";
        aPrototype._v_Type    = "WaitTimes_Login_Behavior";
        aPrototype._v_Kind    = "Behavior";
        aPrototype._v_Layer   = "Services";


        /* Prototype member properties */


        aPrototype._v_ServiceURL    = null;
        aPrototype._v_ApplicationId = null;
        aPrototype._v_ParkName      = null;

        aPrototype._v_DS_AccessToken   = null;


        /* Supply essential contextual parameters */
        var _pInit = function( theServiceURL, theApplicationId, theParkName, theDS_AccessToken) {

            this._v_ServiceURL     = theServiceURL;
            this._v_ApplicationId  = theApplicationId;
            this._v_ParkName       = theParkName;

            this._v_DS_AccessToken = theDS_AccessToken;
        };
        aPrototype._pInit = _pInit;






        var pDo = function( theExecution,thePassword) {

            if( this._v_DS_AccessToken && this._v_DS_AccessToken.value) {
                this._pSuccess( theExecution);
                return;
            }

            if( !thePassword) {
                this._pFailure( theExecution, "No Password");
                return;
            }

            if( !this._v_ServiceURL) {
                this._pFailure( theExecution, "No Service URL supplied");
                return;
            }

            if( !this._v_ApplicationId) {
                this._pFailure( theExecution, "No Application Id supplied");
                return;
            }


            /* Using multiple variables, multiple sentences,
             to facilitate debug during exploration of the solution.
             */
            var aPayload = {
                "action": "login",
                "applicationId": this._v_ApplicationId,
                "password": thePassword,
                "park": this._v_ParkName
            };


            /* Secure reference to 'this',
            because 'this' will not be this this ;-)
            when executing success handler function below
            */
            var aThis = this;

            /*
            var aSuccessHandler = function( theResponse) {
                var aSuccessHandler_here = theSuccessHandler;
                var aErrorHandler_here = theErrorHandler;
                aThis._pLogin_Success( theResponse, aSuccessHandler_here, aErrorHandler_here);
            };

             While it works with JQuery, when switching to Angular $http, got error:
             XMLHttpRequest cannot load http://162.250.78.100/api/api.php. Request header field Content-Type is not allowed by Access-Control-Allow-Headers.
            Fix executing:
            delete $http.defaults.headers.common['X-Requested-With'];

            https://groups.google.com/forum/#!topic/angular/Q1WSuug7Xyc

            $http.post( this._v_ServiceURL, aPayload).success( aSuccessHandler).error( theErrorHandler);

             */


            /* Code below uses JQuery, which is included in the application for this sole purpose.
            Angular offers the service $http, which is easily dependency-injected by refering to it in this module's declaration.
            Angular also offers a subset of JQuery (I believe, the "core" selection rules matching of DOM elements),
            which is available under the same "$" when JQuery has not been also loaded in the application.
            */
            var aPayloadString = JSON.stringify( aPayload);

            var aPromise = $.ajax({
                type: "POST",
                url: this._v_ServiceURL,
                data: aPayloadString,
                success: function( theResponse) {
                    aThis._pSuccess( theExecution, theResponse);
                }
            });

            aPromise.fail( function( theResponse) {
                aThis._pFailure( theExecution, theResponse);
            });


        };
        aPrototype.pDo = pDo;







        var _pSuccess = function( theExecution, theResponse) {

            /* Server shall return:
             {
                 "action": "login",
                 "token": "t_660748397"
             }
             */

            if( !theResponse ) {
                this._pFailure( theExecution, theResponse);
                return;
            }



            /* ACV OJO Firefox does not automatically convert to an object the received JSON payload */
            var aResponse = theResponse;
            if( typeof aResponse == "string") {
                try {
                    aResponse = JSON.parse( aResponse);
                }
                catch( anException) {
                    aResponse = null;
                }
            }

            if( !aResponse ) {
                this._pFailure( theExecution, theResponse);
                return;
            }


            if( !( aResponse.action == "login")) {
                this._pFailure( theExecution, "Unexpected Response");
                return;
            }


            if( !aResponse.token) {
                this._pFailure( theExecution, "No Token from server");
                return;
            }


            this._v_DS_AccessToken.value = aResponse.token;

            theExecution.behaviorSuccess( this, this._v_DS_AccessToken);
        };
        aPrototype._pSuccess = _pSuccess;







        var _pFailure = function( theExecution, theMessage) {

            this._v_DS_AccessToken.value = null;

            theExecution.behaviorFailure( this, theMessage);
        };
        aPrototype._pFailure = _pFailure;



        return aPrototype;

    })();





    /* Define constructor for instances with the prototype. */

    var Login_Behavior_Constructor = function( theServiceURL, theApplicationId, theParkName, theDS_AccessToken) {

        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_ServiceURL = null;
        this._v_ApplicationId = null;
        this._v_ParkName = null;

        this._v_DS_AccessToken = null;

        this._pInit( theServiceURL, theApplicationId, theParkName, theDS_AccessToken);
    };
    Login_Behavior_Constructor.prototype = aLogin_Behavior_Prototype;
















    /* Define prototype. Has no prototype inheritance itself */
    var aObtainWaitTimes_Behavior_Prototype = (function() {

        var aPrototype = {};
        aPrototype._v_Package = "ThemePark";
        aPrototype._v_Type    = "WaitTimes_Obtain_Behavior";
        aPrototype._v_Kind    = "Behavior";
        aPrototype._v_Layer   = "Services";


        /* Prototype member properties */


        aPrototype._v_DS_AccessToken       = null;
        aPrototype._v_DS_ReceivedWaitTimes = null;



        /* Supply essential contextual parameters */
        var _pInit = function( theDS_AccessToken, theDS_ReceivedWaitTimes) {

            this._v_DS_AccessToken       = theDS_AccessToken;
            this._v_DS_ReceivedWaitTimes = theDS_ReceivedWaitTimes;

        };
        aPrototype._pInit = _pInit;





        /* ********************************************
         Retrieve all Wait Times remote service invocation,
         and execute handlers on success or error.

         Success handler quite likely is in charge of re-painting the canvas
         (not that this service cares).
         */

        var pDo = function( theExecution) {

            if( !this._v_DS_AccessToken) {
                this._pFailure( theExecution, "No Access Token");
                return;
            }

            var aPayload = {
                "action": "getAllWaitTimes",
                "token": this._v_DS_AccessToken.value
            };

            var aPayloadString = JSON.stringify( aPayload);

            var aThis = this;
            var aPromise = $.ajax({
                type: "POST",
                url: this._v_ServiceURL,
                data: aPayloadString,
                success: function( theResponse) {
                    aThis._pSuccess( theExecution, theResponse);
                }
            });

            aPromise.fail( function( theResponse) {
                aThis._pFailure( theExecution, theResponse);
            });
        };
        aPrototype.pDo = pDo;






        var _pSuccess = function( theExecution, theResponse) {

            /* Server shall return
             {
                 "action": "getAllWaitTimes",
                 "timeOfDay": "09:06:00",
                 "waitTimes": {
                     "a11": 140,
                     "a8": 190,
                     "a1": 110,
                     "a7": 10,
                     "a5": 40,
                     "a9": 0,
                     "a3": 0,
                     "a10": 50,
                     "a12": 50,
                     "a14": 150,
                     "a4": 80,
                     "a6": 50,
                     "a2": 220,
                     "a13": 10,
                     "a15": 240
                 }
             }
             */


            if( !theResponse ) {
                this._pFailure( theExecution, theResponse);
                return;
            }



            /* ACV OJO Firefox does not automatically convert to an object the received JSON payload */
            var aResponse = theResponse;
            if( typeof aResponse == "string") {
                try {
                    aResponse = JSON.parse( aResponse);
                }
                catch( anException) {
                    aResponse = null;
                }
            }

            if( !aResponse ) {
                this._pFailure( theExecution, theResponse);
                return;
            }


            if( !( aResponse.action == "getAllWaitTimes")) {
                this._pFailure( theExecution, "Unexpected Response");
                return;
            }


            if( !aResponse.waitTimes) {
                this._pFailure( theExecution, "No Wait Times received from server");
                return;
            }


            this._v_DS_ReceivedWaitTimes.value = aResponse.waitTimes;

            theExecution.behaviorSuccess( this, this._v_DS_ReceivedWaitTimes);
        };
        aPrototype._pSuccess = _pSuccess;





        var _pFailure = function( theExecution, theMessage) {

            this._v_DS_ReceivedWaitTimes.value = null;

            theExecution.behaviorFailure( this, theMessage);
        };
        aPrototype._pFailure = _pFailure;




        return aPrototype;

    })();





    /* Define constructor for instances with the prototype. */

    var ObtainWaitTimes_Behavior_Constructor = function( theDS_AccessToken, theDS_ReceivedWaitTimes) {

        /* Init object layout with member properties ASAP for the benefit of JIT */
       this._v_DS_AccessToken       = null;
        this._v_DS_ReceivedWaitTimes = null;

        this._pInit( theDS_AccessToken, theDS_ReceivedWaitTimes);
    };
    ObtainWaitTimes_Behavior_Constructor.prototype = aObtainWaitTimes_Behavior_Prototype;














    /* Define prototype. Has no prototype inheritance itself */
    var aLogout_Behavior_Prototype = (function() {

        var aPrototype = {};
        aPrototype._v_Package = "ThemePark";
        aPrototype._v_Type    = "WaitTimes_Logout_Behavior";
        aPrototype._v_Kind    = "Behavior";
        aPrototype._v_Layer   = "Services";


        /* Prototype member properties */


        aPrototype._v_DS_AccessToken       = null;



        /* Supply essential contextual parameters */
        var _pInit = function( theDS_AccessToken) {

            this._v_DS_AccessToken       = theDS_AccessToken;

        };
        aPrototype._pInit = _pInit;





        var pDo = function( theExecution) {
            this._v_DS_AccessToken.value = null;
            theExecution.behaviorSuccess( this, this._v_DS_AccessToken);
        };
        aPrototype.pDo = pDo;



        return aPrototype;

    })();





    /* Define constructor for instances with the prototype. */

    var Logout_Behavior_Constructor = function( theDS_AccessToken) {

        /* Init object layout with member properties ASAP for the benefit of JIT */
        this._v_DS_AccessToken       = null;

        this._pInit( theDS_AccessToken);
    };
    Logout_Behavior_Constructor.prototype = aLogout_Behavior_Prototype;









    /* Returns true because the behavior completed with not further activity to do
    */
    var fLogout_Behavior = function( theExecution, theDS_AccessToken) {

        /* Init object layout with member properties ASAP for the benefit of JIT */
        theDS_AccessToken.value       = null;

        return true;
    };







    /* Define service component with all behaviors. */

    var aService = {
        "Login": {
            "function":    fLogin_Behavior,
            "constructor": Login_Behavior_Constructor,
            "prototype":   aLogin_Behavior_Prototype
        },
        "ObtainWaitTimes": {
            "constructor": ObtainWaitTimes_Behavior_Constructor,
            "prototype":   aObtainWaitTimes_Behavior_Prototype
        },
        "Logout": {
            "function":    fLogout_Behavior
        }
    };

    return aService;

}]);


