'use strict';

/*
 * choreography_example_services.js
 *
 * A Javascript exercise.
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 * 03/14/2014
 */





var mModulo = angular.module("choreographyExample", [ ]);



mModulo.factory("ChoreographyExample", [ "ChoreographyTypes",
function( ChoreographyTypes){



    /* ******************************************
    Create a sample Choreography object network.
    */

    var aService = { };




    var fChoreographyExample = function() {


        var aChoreography = new ChoreographyTypes.Choreography.constructor( "RecommendationChoreography");
        var anActivity_top = aChoreography.activityCompositeCreate( "TopActivity");

        var anActivity_01 = anActivity_top.subActivitySimpleCreate( "Activity_01");
        var anActivity_02 = anActivity_top.subActivityRequestReplyCreate( "Activity_02");
        var anActivity_03 = anActivity_top.subActivityCompositeCreate( "Activity_03");

        var anActivity_03_01 = anActivity_03.subActivitySimpleCreate( "Activity_03_01");
        var anActivity_03_02 = anActivity_03.subActivityRequestReplyCreate( "Activity_03_02");
        var anActivity_03_03 = anActivity_03.subActivityCompositeCreate( "Activity_03_03");

        var anActivity_03_03_01 = anActivity_03_03.subActivitySimpleCreate( "Activity_03_03_01");
        var anActivity_03_03_02 = anActivity_03_03.subActivityRequestReplyCreate( "Activity_03_03_02");
        var anActivity_03_03_02 = anActivity_03_03.subActivityCompositeCreate( "Activity_03_03_03");

        return aChoreography;
    };
    aService.fChoreographyExample = fChoreographyExample;





    return aService;

}]);







