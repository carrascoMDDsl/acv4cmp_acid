'use strict';

/*
 * choreography_recommendation.js
 *
 * A Javascript exercise.
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 * 03/13/2014
 */






var mModulo = angular.module("choreographyRecommendation", [ ]);



mModulo.factory("ChoreographyRecommendation", [
    "ChoreographyTypes",
    "Park_Behaviors",
    "WaitTimes_Behaviors",
function(
    ChoreographyTypes,
    Park_Behaviors,
    WaitTimes_Behaviors
    ){



    /* ******************************************
     Create a sample Choreography object network.
     */


    var SERVICE_URL    = "http://162.250.78.100/api/api.php";
    var APPLICATION_ID = "123456";
    var PARKNAME       = "SeaWorld";



    var aService = { };




    var fChoreographyRecommendation = function() {


        var aChoreography = new ChoreographyTypes.Choreography.constructor( "Recommendation Choreography");
        var anATop = aChoreography.activityCompositeCreate( "TopActivity");

        var aDS_ParksHome = anATop.dataStoreCreate( "ParksHome");
        var aDS_Park = anATop.dataStoreCreate( "Park");

        var aDS_JustReceivedWaitTimes = anATop.dataStoreCreate( "JustReceivedWaitTimes");


        var anA_InitParksHome   = anATop.subActivityCompositeCreate( "InitParksHome");
        var anA_InitExamplePark = anATop.subActivityCompositeCreate( "InitExamplePark");
        var anA_ObtainPark      = anATop.subActivityCompositeCreate( "ObtainPark");

        var anA_RefreshTimer    = anATop.subActivityCompositeCreate( "RefreshTimer");
        var anA_ObtainWaitTimes = anATop.subActivityCompositeCreate( "ObtainWaitTimes");
        var anA_UpdateLabels    = anATop.subActivityCompositeCreate( "UpdateLabelsWithNewerWaitTimes");
        var anA_MergeLastKnown  = anATop.subActivityCompositeCreate( "MergeWithLastKnownWaitTimes");
        var anA_RepaintMap      = anATop.subActivityCompositeCreate( "RepaintMap");

        var anA_ObtainAttractions=anATop.subActivityCompositeCreate( "ObtainAttractionsList");
        var anA_ComputePaths    = anATop.subActivityCompositeCreate( "ComputePathsFromAttraction");
        var anA_ComputeRecom    = anATop.subActivityCompositeCreate( "ComputeRecommendation");
        var anA_UpdateLineArrow = anATop.subActivityCompositeCreate( "UpdateLineAndArrowWithRecommendation");
        var anA_RepaintMapOverlay=anATop.subActivityCompositeCreate( "RepaintMapOverlay");




        /* ********************************************************************
         ObtainPark
        */
        var anA_InitParksHome = anA_ObtainPark.subActivitySimpleCreate( "InitParksHome");
        anA_InitParksHome.behaviorsAdd( Park_Behaviors.InitParksHome);


        var anA_InitExamplePark = anA_ObtainPark.subActivitySimpleCreate( "InitExamplePark");
        anA_InitExamplePark.behaviorsAdd( Park_Behaviors.InitExamplePark);

        anA_ObtainPark.initialActivitiesAdd( anA_InitParksHome);
        anA_ObtainPark.chainCreate( anA_InitParksHome, anA_InitExamplePark);





        /* ********************************************************************
        ObtainWaitTimes
        */
        var aDS_AccessToken = anA_ObtainWaitTimes.dataStoreCreate( "AccessToken");

        var anA_ObtainWaitTimesBegin = anA_ObtainWaitTimes.beginCreate();

        var anA_Login = anA_ObtainWaitTimes.subActivitySimpleCreate( "Login");
        anA_Login.behaviorsAdd( new WaitTimes_Behaviors.Login.constructor(
            SERVICE_URL, APPLICATION_ID, PARKNAME, aDS_AccessToken
        ));

        var anA_RetrieveWaitTimes = anA_ObtainWaitTimes.subActivitySimpleCreate( "ObtainWaitTimes");
        anA_RetrieveWaitTimes.behaviorsAdd( new WaitTimes_Behaviors.ObtainWaitTimes.constructor(
            aDS_AccessToken, aDS_JustReceivedWaitTimes
        ));


        var anOutcome_Success = anA_ObtainWaitTimes.outcomeSuccessCreate( "Success");
        var anOutcome_Failure = anA_ObtainWaitTimes.outcomeFailureCreate( "Failure");



        anA_ObtainWaitTimes.chainCreate( anA_ObtainWaitTimesBegin, anA_Login, function( ) {
            return aDS_AccessToken.value ? false : true;
        });

        anA_ObtainWaitTimes.chainCreate( anA_ObtainWaitTimesBegin, anA_RetrieveWaitTimes, function( ) {
            return aDS_AccessToken.value ? true : false;
        });

        anA_ObtainWaitTimes.chainCreate( anA_Login, anA_RetrieveWaitTimes, function( ) {
            return anA_Login.success() ? true : false;
        });


        anA_ObtainWaitTimes.chainCreate( anA_Login, anOutcome_Success, function( ) {
            return anA_Login.success() ? true : false;
        });

        anA_ObtainWaitTimes.chainCreate( anA_Login, anOutcome_Failure, function( ) {
            return anA_Login.success() ? false : true;
        });

        anA_ObtainWaitTimes.chainCreate( anA_RetrieveWaitTimes, anOutcome_Failure, function( ) {
            return anA_Login.success() ? false : true;
        });


        return aChoreography;
    };
    aService.fChoreographyRecommendation = fChoreographyRecommendation;
    if( fChoreographyRecommendation) {} /* CQT */






    return aService;

}]);










