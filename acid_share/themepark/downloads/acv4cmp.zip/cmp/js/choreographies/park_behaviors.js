'use strict';

/*
 * park_behaviors.js
 *
 * A Javascript exercise.
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 * 03/11/2014
 */



var mModulo = angular.module("parkBehaviorsSupplier", []);



mModulo.factory("Park_Behaviors", [  "ParksModel", function( ParksModel){




    var fInitParksHome = function( theDS_ParksHome) {
        if( !theDS_ParksHome) {
            return false;
        }

        theDS_ParksHome.value = new ParksModel.ParksHome_Constructor();

        return true;
    };





    /* ******************************************
     ******************************************
     Create a sample ParkHome object network.
     */


    var fInitExamplePark = function( theDS_ParksHome, theDS_Park) {
        if( !theDS_ParksHome || !theDS_Park) {
            return false;
        }

        var aParksHome = theDS_ParksHome.value;

        var aPark = aParksHome.parkCreate( "Theme Park 1", "NAVD 88");
        theDS_Park.value = aPark;

        var anAtt_01 = aPark.attractionCreate( "a1", false, 290, 100);
        var anAtt_02 = aPark.attractionCreate( "a2", true,  500, 180);
        var anAtt_03 = aPark.attractionCreate( "a3", true,  320, 220);
        var anAtt_04 = aPark.attractionCreate( "a4", false, 110, 210);
        var anAtt_05 = aPark.attractionCreate( "a5", true,  650, 380);
        var anAtt_06 = aPark.attractionCreate( "a6", false, 520, 410);
        var anAtt_07 = aPark.attractionCreate( "a7", true,  350, 390);
        var anAtt_08 = aPark.attractionCreate( "a8", false, 680, 530);
        var anAtt_09 = aPark.attractionCreate( "a9", false, 120, 480);
        var anAtt_10 = aPark.attractionCreate( "a10", true,  610, 760);
        var anAtt_11 = aPark.attractionCreate( "a11", false, 500, 680);
        var anAtt_12 = aPark.attractionCreate( "a12", false, 510, 850);
        var anAtt_13 = aPark.attractionCreate( "a13", true,  370, 800);
        var anAtt_14 = aPark.attractionCreate( "a14", false, 170, 770);
        var anAtt_15 = aPark.attractionCreate( "a15", false, 110, 680);

        var aCros_01 = aPark.crossingCreate( "c1", 390, 170);
        var aCros_02 = aPark.crossingCreate( "c2", 400, 260);
        var aCros_03 = aPark.crossingCreate( "c3", 230, 160);
        var aCros_04 = aPark.crossingCreate( "c4", 230, 320);
        var aCros_05 = aPark.crossingCreate( "c5", 540, 320);
        var aCros_06 = aPark.crossingCreate( "c6", 440, 460);
        var aCros_07 = aPark.crossingCreate( "c7", 200, 470);
        var aCros_08 = aPark.crossingCreate( "c8", 290, 570);
        var aCros_09 = aPark.crossingCreate( "c9", 440, 610);
        var aCros_10 = aPark.crossingCreate( "c10", 590, 640);
        var aCros_11 = aPark.crossingCreate( "c11", 400, 730);
        var aCros_12 = aPark.crossingCreate( "c12", 200, 690);
        var aCros_13 = aPark.crossingCreate( "c13", 120, 590);


        var aRoad_01 = aPark.roadCreate( "r1", anAtt_02, aCros_02);
        var aRoad_02 = aPark.roadCreate( "r2", anAtt_02, aCros_01);
        var aRoad_03 = aPark.roadCreate( "r3", aCros_01, aCros_02);
        var aRoad_04 = aPark.roadCreate( "r4", anAtt_01, aCros_01);
        var aRoad_05 = aPark.roadCreate( "r5", aCros_02, aCros_04);
        var aRoad_06 = aPark.roadCreate( "r6", anAtt_03, aCros_04);
        var aRoad_07 = aPark.roadCreate( "r7", anAtt_01, aCros_03);
        var aRoad_08 = aPark.roadCreate( "r8", aCros_03, aCros_04);
        var aRoad_09 = aPark.roadCreate( "r9", aCros_03, anAtt_04);
        var aRoad_10 = aPark.roadCreate( "r10", anAtt_04, aCros_04);
        var aRoad_11 = aPark.roadCreate( "r11", aCros_04, anAtt_07);
        var aRoad_12 = aPark.roadCreate( "r12", aCros_04, aCros_07);
        var aRoad_13 = aPark.roadCreate( "r13", anAtt_05, aCros_05);
        var aRoad_14 = aPark.roadCreate( "r14", anAtt_06, aCros_06);
        var aRoad_15 = aPark.roadCreate( "r15", aCros_05, aCros_06);
        var aRoad_16 = aPark.roadCreate( "r16", aCros_05, anAtt_07);
        var aRoad_17 = aPark.roadCreate( "r17", anAtt_07, aCros_06);
        var aRoad_18 = aPark.roadCreate( "r18", aCros_06, anAtt_08);
        var aRoad_19 = aPark.roadCreate( "r19", anAtt_08, aCros_10);
        var aRoad_20 = aPark.roadCreate( "r20", aCros_10, aCros_09);
        var aRoad_21 = aPark.roadCreate( "r21", aCros_09, aCros_08);
        var aRoad_22 = aPark.roadCreate( "r22", aCros_06, aCros_08);
        var aRoad_23 = aPark.roadCreate( "r23", aCros_08, aCros_07);
        var aRoad_24 = aPark.roadCreate( "r24", aCros_07, aCros_13);
        var aRoad_25 = aPark.roadCreate( "r25", aCros_07, anAtt_09);
        var aRoad_26 = aPark.roadCreate( "r26", aCros_13, anAtt_15);
        var aRoad_27 = aPark.roadCreate( "r27", aCros_13, aCros_12);
        var aRoad_28 = aPark.roadCreate( "r28", aCros_12, anAtt_14);
        var aRoad_29 = aPark.roadCreate( "r29", aCros_12, aCros_11);
        var aRoad_30 = aPark.roadCreate( "r30", aCros_09, aCros_11);
        var aRoad_31 = aPark.roadCreate( "r31", anAtt_11, aCros_11);
        var aRoad_32 = aPark.roadCreate( "r32", aCros_10, anAtt_10);
        var aRoad_33 = aPark.roadCreate( "r33", anAtt_10, aCros_11);
        var aRoad_34 = aPark.roadCreate( "r34", anAtt_10, anAtt_12);
        var aRoad_35 = aPark.roadCreate( "r35", anAtt_12, aCros_11);
        var aRoad_36 = aPark.roadCreate( "r36", aCros_11, anAtt_13);

        return true;
    };






    /* Define service component with all behaviors. */

    var aService = {
        "InitParksHome":   { function: fInitParksHome},
        "InitExamplePark": { function: fInitExamplePark}
    };


    return aService;

}]);


