'use strict';

/*
 * dagrams_controllers.js
 *
 * Licensed to CM Productions for the exclusive use of evaluating Antonio Carrasco Valero's (author's) skills and performance as part of a permanent hiring selection process by CM Productions. No other use of this code is authorized. Distribution and copy of this code is prohibited.
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 * 03/12/2014
 */





function DiagramsCtrl($scope) {
    $scope.diagrams = {};
    $scope.diagrams.selectedDiagram = "Map_Components";

}

