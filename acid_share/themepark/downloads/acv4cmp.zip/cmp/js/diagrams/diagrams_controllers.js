'use strict';

/*
 * dagrams_controllers.js
 *
 * A Javascript exercise.
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 * 03/12/2014
 */





function DiagramsCtrl($scope) {
    $scope.diagrams = {};
    $scope.diagrams.selectedDiagram = "Map_Components";

}

