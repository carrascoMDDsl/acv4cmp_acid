'use strict';

/*
 * controllers.js
 *
 * A Javascript exercise.
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 * 03/11/2014
 */









function VoidCtrl($scope) {
}

