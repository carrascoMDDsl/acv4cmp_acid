'use strict';

/*
 * choreography_test_controllers.js
 *
 * A Javascript exercise.
 *
 * Copyright 2014 by the Author of this code Antonio Carrasco Valero
 * 03/13/2014
 */




angular.module('cmpinterviewjs').controller(
    'ChoreographyCtrl',
    [ '$scope', 'ChoreographyExample', 'ChoreographyRecommendation',
function ( $scope, ChoreographyExample, ChoreographyRecommendation) {





    /* Define prototype. Has no prototype inheritance itself */
    var aChoreography_Controller_Prototype = (function() {

        var aPrototype = {};


        /* Prototype members to be used as constants */

        /* UI contract constants */



        /* Prototype member properties */

        aPrototype.choreography = null;



        /* Supply essential context and parameters. Initialize private member properties.
        */
        var _pInit = function() {

            this.choreography = ChoreographyRecommendation.fChoreographyRecommendation();
        };
        if( _pInit) {} /* CQT */
        aPrototype._pInit = _pInit;






        /* Just in case, we need to be alert :-) */
        var _pErrorAlert = function( theMessage) {

            var aMessage = theMessage;
            if( !aMessage) {
                aMessage = "Error";
            }
            /* Modals to be opened out of the current event loop */
            setTimeout(
                function() {
                    alert( aMessage);
                },
                100
            );
        };
        aPrototype._pErrorAlert = _pErrorAlert;




        return aPrototype;

    })();








    /* Define constructor for instances with the prototype. */

    var Choreography_Controller_Constructor = function() {

        /* Init object layout with member properties ASAP for the benefit of JIT */
        this.choreography = null;

        this._pInit();
    };
    Choreography_Controller_Constructor.prototype = aChoreography_Controller_Prototype;







    /* *********************************+
    Decorate the $scope
    */

    $scope.choreographyCtrl = new Choreography_Controller_Constructor();


}]);





